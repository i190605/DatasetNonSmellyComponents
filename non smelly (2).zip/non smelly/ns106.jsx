class InlineAccount extends PureComponent {

    static propTypes = {
      account: ImmutablePropTypes.map.isRequired,
    };
  
    render () {
      const { account } = this.props;
  
      return (
        <span className='inline-account'>
          <Avatar size={13} account={account} /> <strong>{account.get('username')}</strong>
        </span>
      );
    }
  
  }
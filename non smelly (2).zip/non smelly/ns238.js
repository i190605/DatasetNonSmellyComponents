const MouseEnterDetect = () => {
    const [log, setLog] = React.useState({});
    const firstEl = React.useRef();
    const siblingEl = React.useRef();
  
    const onMouseEnter = e => {
      const timeStamp = e.timeStamp;
      setLog(log => {
        const callCount = 1 + (log.timeStamp === timeStamp ? log.callCount : 0);
        return {
          timeStamp,
          callCount,
        };
      });
    };
  
    return (
      <React.Fragment>
        <div
          ref={firstEl}
          onMouseEnter={onMouseEnter}
          style={{
            border: '1px solid #d9d9d9',
            padding: '20px 20px',
          }}>
          Mouse enter call count: {log.callCount || ''}
        </div>
        <div ref={siblingEl} />
      </React.Fragment>
    );
  };
  
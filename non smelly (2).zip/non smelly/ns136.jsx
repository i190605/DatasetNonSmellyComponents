export const HashtagHeader = injectIntl(({ tag, intl, disabled, onClick }) => {
    if (!tag) {
      return null;
    }
  
    const [uses, people] = tag.get('history').reduce((arr, day) => [arr[0] + day.get('uses') * 1, arr[1] + day.get('accounts') * 1], [0, 0]);
    const dividingCircle = <span aria-hidden>{' · '}</span>;
  
    return (
      <div className='hashtag-header'>
        <div className='hashtag-header__header'>
          <h1>#{tag.get('name')}</h1>
          <Button onClick={onClick} text={intl.formatMessage(tag.get('following') ? messages.unfollowHashtag : messages.followHashtag)} disabled={disabled} />
        </div>
  
        <div>
          <ShortNumber value={uses} renderer={usesRenderer} />
          {dividingCircle}
          <ShortNumber value={people} renderer={peopleRenderer} />
          {dividingCircle}
          <ShortNumber value={tag.getIn(['history', 0, 'uses']) * 1} renderer={usesTodayRenderer} />
        </div>
      </div>
    );
  });
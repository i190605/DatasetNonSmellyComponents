export default function ExpandCollapseToggle({
    disabled,
    isOpen,
    setIsOpen,
  }: ExpandCollapseToggleProps): React.Node {
    return (
      <Button
        className={styles.ExpandCollapseToggle}
        disabled={disabled}
        onClick={() => setIsOpen(prevIsOpen => !prevIsOpen)}
        title={`${isOpen ? 'Collapse' : 'Expand'} prop value`}>
        <ButtonIcon type={isOpen ? 'expanded' : 'collapsed'} />
      </Button>
    );
  }
  
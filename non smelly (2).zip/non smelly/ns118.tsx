export const VerifiedBadge: React.FC<Props> = ({ link }) => (
    <span className='verified-badge'>
      <Icon id='check' className='verified-badge__mark' />
      <span dangerouslySetInnerHTML={stripRelMe(link)} />
    </span>
  );
  
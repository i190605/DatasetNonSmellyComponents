unction DateParameter(props) {
    return (
      <DynamicDatePicker
        dynamicButtonOptions={{ options: DYNAMIC_DATE_OPTIONS }}
        {...props}
        dateOptions={{ "aria-label": "Parameter date value" }}
      />
    );
  }
  
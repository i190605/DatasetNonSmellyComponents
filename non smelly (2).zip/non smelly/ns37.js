const colorPickerStyle = {
    backgroundColor: COLORS.BLACK,
    padding: 0,
    margin: '4px',
  }
  
  const colorPresets = []
  
  const HighlightPicker = ({ title, onChange, color }) => (
    <div className="color-picker-container">
      <div className="color-picker-header">
        <span className="capitalize">{title}</span>
      </div>
      <ColorPicker
        key={title}
        color={color}
        onChange={onChange}
        presets={colorPresets}
        style={colorPickerStyle}
      />
      <style jsx>
        {`
          .color-picker-container {
            width: 218px;
            border-left: 2px solid ${COLORS.SECONDARY};
            padding: 2px;
          }
  
          .color-picker-header {
            background-color: ${COLORS.BLACK};
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 8px 0;
          }
        `}
      </style>
    </div>
  )
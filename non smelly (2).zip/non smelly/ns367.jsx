export default function CheckboxField({ form, field, ...otherProps }) {
    const fieldLabel = getFieldLabel(field);
    return <Checkbox {...otherProps}>{fieldLabel}</Checkbox>;
  }
  
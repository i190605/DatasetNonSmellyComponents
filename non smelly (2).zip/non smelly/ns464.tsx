export const visualizationsSettings = {
    HelpTriggerComponent: HelpTrigger,
    LinkComponent: Link,
    dateFormat: "DD/MM/YYYY",
    dateTimeFormat: "DD/MM/YYYY HH:mm",
    integerFormat: "0,0",
    floatFormat: "0,0.00",
    booleanValues: ["false", "true"],
    tableCellMaxJSONSize: 50000,
    allowCustomJSVisualizations: false,
    hidePlotlyModeBar: false,
    choroplethAvailableMaps: {},
  };
  
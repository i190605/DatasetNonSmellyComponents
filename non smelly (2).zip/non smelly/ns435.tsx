export const ErrorBoundaryContext = React.createContext({
    handleError: (error: any) => {
      // Allow calling chain to roll up, and then throw the error in global context
      setTimeout(() => {
        throw error;
      });
    },
    reset: () => {},
  });
  
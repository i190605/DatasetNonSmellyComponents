function LoginButton({ isVisible, toggleVisibility }) {
    const user = useAuth()
  
    if (!firebase) {
      return null
    }
  
    return (
      <div>
        <Button
          center
          border
          large
          padding="0 16px"
          color="white"
          className="profile-button"
          onClick={() => {
            if (!user) {
              loginGitHub()
            } else {
              toggleVisibility()
            }
          }}
        >
          <img
            height={20}
            src={user ? user.photoURL : '/static/svg/github.svg'}
            alt={user ? user.displayName : 'GitHub'}
          />
          <span>{user ? user.displayName : 'Sign in/up'}</span>
        </Button>
        <Drawer isVisible={user && isVisible} />
        <style jsx>
          {`
            div,
            div :global(.profile-button) {
              position: relative;
              height: 100%;
            }
            div :global(.profile-button) {
              max-width: 218px;
              min-height: 40px;
            }
            span {
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            }
            img {
              border-radius: 50%;
              margin-right: 16px;
            }
          `}
        </style>
      </div>
    )
  }
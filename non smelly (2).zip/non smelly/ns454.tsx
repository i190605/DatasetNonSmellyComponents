function calcIqr(k: any) {
    return (d: any) => {
      const q1 = d.quartiles[0];
      const q3 = d.quartiles[2];
      const iqr = (q3 - q1) * k;
  
      let i = -1;
      let j = d.length;
  
      i += 1;
      while (d[i] < q1 - iqr) {
        i += 1;
      }
  
      j -= 1;
      while (d[j] > q3 + iqr) {
        j -= 1;
      }
  
      return [i, j];
    };
  }
  
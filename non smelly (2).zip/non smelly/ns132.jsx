class Statuses extends PureComponent {

    static propTypes = {
      statusIds: ImmutablePropTypes.list,
      isLoading: PropTypes.bool,
      hasMore: PropTypes.bool,
      multiColumn: PropTypes.bool,
      dispatch: PropTypes.func.isRequired,
    };
  
    componentDidMount () {
      const { dispatch } = this.props;
      dispatch(fetchTrendingStatuses());
    }
  
    handleLoadMore = debounce(() => {
      const { dispatch } = this.props;
      dispatch(expandTrendingStatuses());
    }, 300, { leading: true });
  
    render () {
      const { isLoading, hasMore, statusIds, multiColumn } = this.props;
  
      const emptyMessage = <FormattedMessage id='empty_column.explore_statuses' defaultMessage='Nothing is trending right now. Check back later!' />;
  
      return (
        <>
          <DismissableBanner id='explore/statuses'>
            <FormattedMessage id='dismissable_banner.explore_statuses' defaultMessage='These are posts from across the social web that are gaining traction today. Newer posts with more boosts and favorites are ranked higher.' />
          </DismissableBanner>
  
          <StatusList
            trackScroll
            timelineId='explore'
            statusIds={statusIds}
            scrollKey='explore-statuses'
            hasMore={hasMore}
            isLoading={isLoading}
            onLoadMore={this.handleLoadMore}
            emptyMessage={emptyMessage}
            bindToDocument={!multiColumn}
            withCounters
          />
        </>
      );
    }
  
  }
  
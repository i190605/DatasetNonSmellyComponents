function CopyEmbed({ mapper, title }) {
    const { asPath } = useRouter()
    const text = React.useMemo(() => mapper(asPath), [mapper, asPath])
    const { onClick, copied } = useCopyTextHandler(text)
  
    return <CopyButton onClick={onClick}>{copied ? 'Copied!' : title}</CopyButton>
  }
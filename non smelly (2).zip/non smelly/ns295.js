export default function SuspendingErrorView({
    callStack,
    componentStack,
    errorMessage,
  }: Props): React.Node {
    const maybeItem =
      errorMessage !== null ? findGitHubIssue(errorMessage) : null;
  
    let GitHubUI;
    if (maybeItem != null) {
      GitHubUI = <UpdateExistingIssue gitHubIssue={maybeItem} />;
    } else {
      GitHubUI = (
        <ReportNewIssue
          callStack={callStack}
          componentStack={componentStack}
          errorMessage={errorMessage}
        />
      );
    }
  
    return (
      <>
        {GitHubUI}
        <WorkplaceGroup />
      </>
    );
  }
  
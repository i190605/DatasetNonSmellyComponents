function DefaultLinkComponent({ children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) {
    return <a {...props}>{children}</a>;
  }
  
  Link.Component = DefaultLinkComponent;
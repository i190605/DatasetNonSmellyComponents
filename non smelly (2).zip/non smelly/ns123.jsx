class AccountNavigation extends PureComponent {

    static propTypes = {
      match: PropTypes.shape({
        params: PropTypes.shape({
          acct: PropTypes.string,
          tagged: PropTypes.string,
        }).isRequired,
      }).isRequired,
  
      accountId: PropTypes.string,
      isLoading: PropTypes.bool,
    };
  
    render () {
      const { accountId, isLoading, match: { params: { tagged } } } = this.props;
  
      if (isLoading) {
        return null;
      }
  
      return (
        <>
          <div className='flex-spacer' />
          <FeaturedTags accountId={accountId} tagged={tagged} />
        </>
      );
    }
  
  }
  
class FollowRequestsColumnLink extends Component {

    static propTypes = {
      dispatch: PropTypes.func.isRequired,
      count: PropTypes.number.isRequired,
      intl: PropTypes.object.isRequired,
    };
  
    componentDidMount () {
      const { dispatch } = this.props;
  
      dispatch(fetchFollowRequests());
    }
  
    render () {
      const { count, intl } = this.props;
  
      if (count === 0) {
        return null;
      }
  
      return (
        <ColumnLink
          transparent
          to='/follow_requests'
          icon={<IconWithBadge className='column-link__icon' id='user-plus' count={count} />}
          text={intl.formatMessage(messages.text)}
        />
      );
    }
  
  }
  
function readModule(record, createPromise) {
    if (record.status === 'fulfilled') {
      return record.result;
    }
    if (record.status === 'rejected') {
      throw record.result;
    }
    if (!record.promise) {
      record.promise = createPromise().then(
        value => {
          if (record.status === 'pending') {
            record.status = 'fulfilled';
            record.promise = null;
            record.result = value;
          }
        },
        error => {
          if (record.status === 'pending') {
            record.status = 'rejected';
            record.promise = null;
            record.result = error;
          }
        }
      );
    }
    throw record.promise;
  }
  
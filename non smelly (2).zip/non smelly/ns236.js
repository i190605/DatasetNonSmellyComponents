class MouseEvents extends React.Component {
    render() {
      return (
        <FixtureSet title="Mouse Events">
          <MouseMovement />
          <MouseEnter />
        </FixtureSet>
      );
    }
  }
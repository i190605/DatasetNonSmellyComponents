export default function NativeStyleEditorWrapper(_: Props): React.Node {
    const store = useContext(StoreContext);
  
    const subscription = useMemo(
      () => ({
        getCurrentValue: () => store.supportsNativeStyleEditor,
        subscribe: (callback: Function) => {
          store.addListener('supportsNativeStyleEditor', callback);
          return () => {
            store.removeListener('supportsNativeStyleEditor', callback);
          };
        },
      }),
      [store],
    );
    const supportsNativeStyleEditor = useSubscription<boolean>(subscription);
  
    if (!supportsNativeStyleEditor) {
      return null;
    }
  
    return <NativeStyleEditor />;
  }
  
export default function App({assets}) {
    return (
      <Html assets={assets} title="Hello">
        <Suspense fallback={<Spinner />}>
          <ErrorBoundary FallbackComponent={Error}>
            <Content />
          </ErrorBoundary>
        </Suspense>
      </Html>
    );
  }
function NativeStyleEditor(_: Props) {
    const {getStyleAndLayout} = useContext(NativeStyleContext);
  
    const {inspectedElementID} = useContext(TreeStateContext);
    if (inspectedElementID === null) {
      return null;
    }
  
    const maybeStyleAndLayout = getStyleAndLayout(inspectedElementID);
    if (maybeStyleAndLayout === null) {
      return null;
    }
  
    const {layout, style} = maybeStyleAndLayout;
  
    return (
      <Fragment>
        {layout !== null && (
          <LayoutViewer id={inspectedElementID} layout={layout} />
        )}
        {style !== null && (
          <StyleEditor
            id={inspectedElementID}
            style={style !== null ? style : {}}
          />
        )}
      </Fragment>
    );
  }
  
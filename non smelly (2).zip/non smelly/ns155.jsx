const makeMapStateToProps = () => {
    const getAccount = makeGetAccount();
  
    const mapStateToProps = state => ({
      account: getAccount(state, state.getIn(['blocks', 'new', 'account_id'])),
    });
  
    return mapStateToProps;
  };
  
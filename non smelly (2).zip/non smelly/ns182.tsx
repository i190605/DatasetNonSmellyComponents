function ExtensionBadge(props: Props) {
	const style = styleSelector(null, props);
	const assets = platformAssets(props.type);

	const onClick = () => {
		void bridge().openExternal(props.url);
	};

	const rootStyle = props.style ? { ...style.root, ...props.style } : style.root;

	return (
		<a style={rootStyle} onClick={onClick} href="#">
			<img style={style.logo} src={assets.logoImage}/>
			<div style={style.labelGroup} >
				<div>{_('Get it now:')}</div>
				<div style={style.locationLabel}>{assets.locationLabel}</div>
			</div>
		</a>
	);
}

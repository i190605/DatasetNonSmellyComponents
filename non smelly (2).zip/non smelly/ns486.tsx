
export const FormSelect = React.forwardRef<HTMLButtonElement, FormSelectProps>(
  function FormSelect({ name, ...props }, ref) {
    const form = Ariakit.useFormContext();
    if (!form) throw new Error("FormSelect must be used within a Form");

    const value = form.useValue(name);

    const select = (
      <Select
        ref={ref}
        value={value}
        setValue={(value) => form.setValue(name, value)}
        render={props.render}
      />
    );
    const field = <Ariakit.FormField name={name} render={select} />;
    return <Ariakit.Role.button {...props} render={field} />;
  },
);

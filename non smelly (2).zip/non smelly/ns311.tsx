
export function UserSessionWrapper<P>({ bodyClass, currentRoute, render }: UserSessionWrapperProps<P>) {
    const [isAuthenticated, setIsAuthenticated] = useState(!!Auth.isAuthenticated());
    useEffect(() => {
      let isCancelled = false;
      Promise.all([Auth.requireSession(), organizationStatus.refresh(), policy.refresh()])
        .then(() => {
          if (!isCancelled) {
            setIsAuthenticated(!!Auth.isAuthenticated());
          }
        })
        .catch(() => {
          if (!isCancelled) {
            setIsAuthenticated(false);
          }
        });
      return () => {
        isCancelled = true;
      };
    }, []);
  
    useEffect(() => {
      if (bodyClass) {
        document.body.classList.toggle(bodyClass, true);
        return () => {
          document.body.classList.toggle(bodyClass, false);
        };
      }
    }, [bodyClass]);
  
    if (!isAuthenticated) {
      return null;
    }
  
    return (
      <ApplicationLayout>
        <React.Fragment key={currentRoute.key}>
          {/* @ts-expect-error FIXME */}
          <ErrorBoundary renderError={(error: Error) => <ErrorMessage error={error} />}>
            <ErrorBoundaryContext.Consumer>
              {(
                {
                  handleError,
                } /* : { handleError: UserSessionWrapperRenderChildrenProps<P>["onError"] } FIXME bring back type */
              ) => render({ ...currentRoute.routeParams, pageTitle: currentRoute.title, onError: handleError })}
            </ErrorBoundaryContext.Consumer>
          </ErrorBoundary>
        </React.Fragment>
      </ApplicationLayout>
    );
  }
  
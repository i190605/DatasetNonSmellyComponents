export default function SearchingGitHubIssues(): React.Node {
    return (
      <div className={styles.GitHubLinkRow}>
        <LoadingAnimation className={styles.LoadingIcon} />
        Searching GitHub for reports of this error...
      </div>
    );
  }
  
export const ImmutableHashtag = ({ hashtag }) => (
    <Hashtag
      name={hashtag.get('name')}
      to={`/tags/${hashtag.get('name')}`}
      people={hashtag.getIn(['history', 0, 'accounts']) * 1 + hashtag.getIn(['history', 1, 'accounts']) * 1}
      // @ts-expect-error
      history={hashtag.get('history').reverse().map((day) => day.get('uses')).toArray()}
    />
  );
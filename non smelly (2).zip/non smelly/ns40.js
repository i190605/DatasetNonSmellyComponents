export default function ProcessingData(): React.Node {
    return (
      <div className={styles.Column}>
        <div className={styles.Header}>Processing data...</div>
        <div className={styles.Row}>This should only take a minute.</div>
      </div>
    );
  }
  
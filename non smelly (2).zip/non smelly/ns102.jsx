class SilentErrorBoundary extends Component {

    static propTypes = {
      children: PropTypes.node,
    };
  
    state = {
      error: false,
    };
  
    componentDidCatch() {
      this.setState({ error: true });
    }
  
    render() {
      if (this.state.error) {
        return null;
      }
  
      return this.props.children;
    }
  
  }
  
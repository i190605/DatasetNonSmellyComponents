export default function LoadingState(props) {
    return (
      <div className="text-center">
        <BigMessage icon="fa-spinner fa-2x fa-pulse" message="Loading..." {...props} />
      </div>
    );
  }
  
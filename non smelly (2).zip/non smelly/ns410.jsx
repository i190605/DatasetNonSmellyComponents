export default function QueryViewButton({ title, shortcut, disabled, children, onClick, ...props }) {
    const [tooltipVisible, setTooltipVisible] = useState(false);
  
    const eventHandlers = useMemo(
      () => ({
        onMouseEnter: () => setTooltipVisible(true),
        onMouseLeave: () => setTooltipVisible(false),
      }),
      []
    );
  
    useEffect(() => {
      if (disabled) {
        setTooltipVisible(false);
      }
    }, [disabled]);
  
    useEffect(() => {
      if (shortcut) {
        const shortcuts = {
          [shortcut]: onClick,
        };
  
        KeyboardShortcuts.bind(shortcuts);
        return () => {
          KeyboardShortcuts.unbind(shortcuts);
        };
      }
    }, [shortcut, onClick]);
  
    return (
      <ButtonTooltip title={title} shortcut={shortcut} visible={tooltipVisible}>
        <span {...eventHandlers}>
          <Button
            data-test="ExecuteButton"
            disabled={disabled}
            onClick={onClick}
            style={disabled ? { pointerEvents: "none" } : {}}
            {...props}>
            {children}
          </Button>
        </span>
      </ButtonTooltip>
    );
  }
  
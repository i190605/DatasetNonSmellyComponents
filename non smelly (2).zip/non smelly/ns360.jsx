export function getParamValuesSnapshot(mappings, dashboardParameters) {
    return map(
      sortBy(mappings, m => m.name),
      m => {
        let param;
        switch (m.type) {
          case MappingType.StaticValue:
            return [m.name, m.value];
          case MappingType.WidgetLevel:
            return [m.name, m.param.value];
          case MappingType.DashboardAddNew:
          case MappingType.DashboardMapToExisting:
            param = find(dashboardParameters, p => p.name === m.mapTo);
            return [m.name, param ? param.value : null];
          // no default
        }
      }
    );
  }
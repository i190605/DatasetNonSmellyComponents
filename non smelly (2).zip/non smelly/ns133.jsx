class Suggestions extends PureComponent {

    static propTypes = {
      isLoading: PropTypes.bool,
      suggestions: ImmutablePropTypes.list,
      dispatch: PropTypes.func.isRequired,
    };
  
    componentDidMount () {
      const { dispatch } = this.props;
      dispatch(fetchSuggestions(true));
    }
  
    render () {
      const { isLoading, suggestions } = this.props;
  
      if (!isLoading && suggestions.isEmpty()) {
        return (
          <div className='explore__suggestions scrollable scrollable--flex'>
            <div className='empty-column-indicator'>
              <FormattedMessage id='empty_column.explore_statuses' defaultMessage='Nothing is trending right now. Check back later!' />
            </div>
          </div>
        );
      }
  
      return (
        <div className='explore__suggestions'>
          {isLoading ? <LoadingIndicator /> : suggestions.map(suggestion => (
            <AccountCard key={suggestion.get('account')} id={suggestion.get('account')} />
          ))}
        </div>
      );
    }
  
  }
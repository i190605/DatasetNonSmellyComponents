export default function CardsList({ items = [], showSearch = false }: CardsListProps) {
    const [searchText, setSearchText] = useState("");
    const filteredItems = items.filter(
      item => isEmpty(searchText) || includes(item.title.toLowerCase(), searchText.toLowerCase())
    );
  
    return (
      <div data-test="CardsList">
        {showSearch && (
          <div className="row p-10">
            <div className="col-md-4 col-md-offset-4">
              <Input.Search
                placeholder="Search..."
                aria-label="Search cards"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchText(e.target.value)}
                autoFocus
              />
            </div>
          </div>
        )}
        {isEmpty(filteredItems) ? (
          <EmptyState className="" />
        ) : (
          <div className="row">
            <div className="col-lg-12 d-inline-flex flex-wrap visual-card-list">
              {filteredItems.map((item: CardsListItem, index: number) => (
                <ListItem key={index} item={item} keySuffix={index.toString()} />
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }
  
function getPopupPosition(width, height) {
    const windowLeft = window.screenX;
    const windowTop = window.screenY;
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
  
    return {
      left: Math.floor((windowWidth - width) / 2 + windowLeft),
      top: Math.floor((windowHeight - height) / 2 + windowTop),
      width: Math.floor(width),
      height: Math.floor(height),
    };
  }
  
const MouseEnter = () => {
    const containerRef = React.useRef();
  
    React.useEffect(function () {
      const hostEl = containerRef.current;
      ReactDOM.render(<MouseEnterDetect />, hostEl, () => {
        ReactDOM.render(<MouseEnterDetect />, hostEl.childNodes[1]);
      });
    }, []);
  
    return (
      <TestCase
        title="Mouse Enter"
        description=""
        affectedBrowsers="Chrome, Safari, Firefox">
        <TestCase.Steps>
          <li>Mouse enter the boxes below, from different borders</li>
        </TestCase.Steps>
        <TestCase.ExpectedResult>
          Mouse enter call count should equal to 1; <br />
          Issue{' '}
          <a
            rel="noopener noreferrer"
            target="_blank"
            href="https://github.com/facebook/react/issues/16763">
            #16763
          </a>{' '}
          should not happen.
          <br />
        </TestCase.ExpectedResult>
        <div ref={containerRef} />
      </TestCase>
    );
  };
export const ColumnSettings: React.FC = () => {
    const settings = useAppSelector((state) => state.settings.get('home'));
  
    const dispatch = useAppDispatch();
    const onChange = useCallback(
      (key: string, checked: boolean) => {
        dispatch(changeSetting(['home', ...key], checked));
      },
      [dispatch],
    );
  
    return (
      <div>
        <span className='column-settings__section'>
          <FormattedMessage
            id='home.column_settings.basic'
            defaultMessage='Basic'
          />
        </span>
  
        <div className='column-settings__row'>
          <SettingToggle
            prefix='home_timeline'
            settings={settings}
            settingPath={['shows', 'reblog']}
            onChange={onChange}
            label={
              <FormattedMessage
                id='home.column_settings.show_reblogs'
                defaultMessage='Show boosts'
              />
            }
          />
        </div>
  
        <div className='column-settings__row'>
          <SettingToggle
            prefix='home_timeline'
            settings={settings}
            settingPath={['shows', 'reply']}
            onChange={onChange}
            label={
              <FormattedMessage
                id='home.column_settings.show_replies'
                defaultMessage='Show replies'
              />
            }
          />
        </div>
      </div>
    );
  };
  
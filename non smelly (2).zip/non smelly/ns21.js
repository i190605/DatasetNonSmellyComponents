export const MetaLinks = React.memo(() => {
    return (
      <React.Fragment>
        <Link
          href={`//cdnjs.cloudflare.com/ajax/libs/codemirror/${CODEMIRROR_VERSION}/theme/seti.min.css`}
        />
        <CodeMirrorLink />
        {LOCAL_STYLESHEETS.map(id => (
          <Link key={id} href={`/static/themes/${id}.min.css`} />
        ))}
        {CDN_STYLESHEETS.map(themeDef => {
          const href = `//cdnjs.cloudflare.com/ajax/libs/codemirror/${CODEMIRROR_VERSION}/theme/${
            themeDef && (themeDef.link || themeDef.id)
          }.min.css`
          return <Link key={themeDef.id} href={href} />
        })}
      </React.Fragment>
    )
  })
  
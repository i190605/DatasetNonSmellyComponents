class Category extends PureComponent {

    static propTypes = {
      onNextStep: PropTypes.func.isRequired,
      rules: ImmutablePropTypes.list,
      category: PropTypes.string,
      onChangeCategory: PropTypes.func.isRequired,
      startedFrom: PropTypes.oneOf(['status', 'account']),
      intl: PropTypes.object.isRequired,
    };
  
    handleNextClick = () => {
      const { onNextStep, category } = this.props;
  
      switch(category) {
      case 'dislike':
        onNextStep('thanks');
        break;
      case 'violation':
        onNextStep('rules');
        break;
      default:
        onNextStep('statuses');
        break;
      }
    };
  
    handleCategoryToggle = (value, checked) => {
      const { onChangeCategory } = this.props;
  
      if (checked) {
        onChangeCategory(value);
      }
    };
  
    render () {
      const { category, startedFrom, rules, intl } = this.props;
  
      const options = rules.size > 0 ? [
        'dislike',
        'spam',
        'legal',
        'violation',
        'other',
      ] : [
        'dislike',
        'spam',
        'legal',
        'other',
      ];
  
      return (
        <>
          <h3 className='report-dialog-modal__title'><FormattedMessage id='report.category.title' defaultMessage="Tell us what's going on with this {type}" values={{ type: intl.formatMessage(messages[startedFrom]) }} /></h3>
          <p className='report-dialog-modal__lead'><FormattedMessage id='report.category.subtitle' defaultMessage='Choose the best match' /></p>
  
          <div>
            {options.map(item => (
              <Option
                key={item}
                name='category'
                value={item}
                checked={category === item}
                onToggle={this.handleCategoryToggle}
                label={intl.formatMessage(messages[item])}
                description={intl.formatMessage(messages[`${item}_description`])}
              />
            ))}
          </div>
  
          <div className='flex-spacer' />
  
          <div className='report-dialog-modal__actions'>
            <Button onClick={this.handleNextClick} disabled={category === null}><FormattedMessage id='report.next' defaultMessage='Next' /></Button>
          </div>
        </>
      );
    }
  
  }
  
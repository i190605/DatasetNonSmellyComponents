function DateTimeFormatSpecs() {
    const { HelpTriggerComponent } = visualizationsSettings;
    return (
      <HelpTriggerComponent
        title="Formatting Dates and Times"
        href="https://momentjs.com/docs/#/displaying/format/"
        className="visualization-editor-context-help">
        {ContextHelp.defaultIcon}
      </HelpTriggerComponent>
    );
  }
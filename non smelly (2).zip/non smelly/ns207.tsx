const ConfigScreenButton: FunctionComponent<Props> = props => {
	let descriptionComp = null;
	if (props.description) {
		descriptionComp = (
			<View style={{ flex: 1, marginTop: 10 }}>
				<Text style={props.styles.descriptionText}>{props.description}</Text>
			</View>
		);
	}

	return (
		<View style={props.styles.settingContainer}>
			<View style={{ flex: 1, flexDirection: 'column' }}>
				<View style={{ flex: 1 }}>
					<Button title={props.title} onPress={props.clickHandler} disabled={!!props.disabled} />
				</View>
				{props.statusComponent}
				{descriptionComp}
			</View>
		</View>
	);
};

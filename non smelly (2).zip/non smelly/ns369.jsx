export default function NumberField({ form, field, ...otherProps }) {
    return <InputNumber {...otherProps} />;
  }
  
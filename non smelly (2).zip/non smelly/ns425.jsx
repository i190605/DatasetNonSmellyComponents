
export function notifySessionRestored() {
    if (window.opener) {
      window.opener.postMessage({ type: SESSION_RESTORED_MESSAGE }, window.location.origin);
    }
  }
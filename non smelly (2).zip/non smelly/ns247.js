class OnSelectIframe extends React.Component {
    state = {count: 0, value: 'Select Me!'};
  
    _onSelect = event => {
      this.setState(({count}) => ({count: count + 1}));
    };
  
    _onChange = event => {
      this.setState({value: event.target.value});
    };
  
    render() {
      const {count, value} = this.state;
      return (
        <Iframe height={60}>
          Selection Event Count: {count}
          <input
            type="text"
            onSelect={this._onSelect}
            value={value}
            onChange={this._onChange}
          />
        </Iframe>
      );
    }
  }
export default function Example() {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  const matches = useMemo(() => {
    return matchSorter(links, searchValue, {
      keys: ["children"],
      baseSort: (a, b) => (a.index < b.index ? -1 : 1),
    });
  }, [searchValue]);

  return (
    <div className="wrapper">
      <Ariakit.ComboboxProvider
        open={open}
        setOpen={setOpen}
        setValue={(value) => startTransition(() => setSearchValue(value))}
      >
        <label className="label">
          Links
          <Ariakit.Combobox
            placeholder="e.g., Twitter"
            className="combobox"
            autoSelect
          />
        </label>
        {open && (
          <Ariakit.ComboboxPopover gutter={4} sameWidth className="popover">
            {matches.length ? (
              matches.map(({ children, ...props }) => (
                <Ariakit.ComboboxItem
                  key={children}
                  focusOnHover
                  hideOnClick
                  className="combobox-item"
                  render={<a {...props} />}
                >
                  {children}
                  {props.target === "_blank" && (
                    <NewWindow className="combobox-item-icon" />
                  )}
                </Ariakit.ComboboxItem>
              ))
            ) : (
              <div className="no-results">No results found</div>
            )}
          </Ariakit.ComboboxPopover>
        )}
      </Ariakit.ComboboxProvider>
    </div>
  );
}

export default function Example() 
{
  return <Separator orientation="horizontal" className="separator" />;
}

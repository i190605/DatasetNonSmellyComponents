class FixtureSet extends React.Component {
    render() {
      const {title, description, children} = this.props;
  
      return (
        <div className="container">
          <h1>{title}</h1>
          {description && <p>{description}</p>}
  
          {children}
        </div>
      );
    }
  }
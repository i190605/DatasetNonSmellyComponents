
const ActionButton = (props: ActionButtonProps) => {
	const [open, setOpen] = useState(false);
	const onMenuToggled = useCallback(
		(state: { open: boolean }) => setOpen(state.open)
		, [setOpen]);


	const actions = useMemo(() => (props.buttons ?? []).map(button => {
		return {
			...button,
			icon: getIconRenderFunction(button.icon),
			onPress: button.onPress ?? defaultOnPress,
		};
	}), [props.buttons]);

	const closedIcon = useIcon(props.mainButton?.icon ?? 'md-add');
	const openIcon = useIcon('close');

	return (
		<Portal>
			<FAB.Group
				open={open}
				accessibilityLabel={props.mainButton?.label ?? _('Add new')}
				icon={ open ? openIcon : closedIcon }
				fabStyle={{
					backgroundColor: props.mainButton?.color ?? 'rgba(231,76,60,1)',
				}}
				onStateChange={onMenuToggled}
				actions={actions}
				onPress={props.mainButton?.onPress ?? defaultOnPress}
				visible={true}
			/>
		</Portal>
	);
};

class Routes {
    _items: RouteItem[] = [];
    _sorted = false;
  
    get items(): RouteItem[] {
      if (!this._sorted) {
        this._items = sortBy(this._items, [
          item => getRouteParamsCount(item.path), // simple definitions first, with more params - last
          item => -item.path.length, // longer first
          item => item.path, // if same type and length - sort alphabetically
        ]);
        this._sorted = true;
      }
      return this._items;
    }
  
    public register<P>(id: string, route: RedashRoute<P>) {
      const idOrNull = isString(id) ? id : null;
      this.unregister(idOrNull);
      if (isObject(route)) {
        this._items = [...this.items, { ...route, id: idOrNull }];
        this._sorted = false;
      }
    }
  
    public unregister(id: string | null) {
      if (isString(id)) {
        // removing item does not break their order (if already sorted)
        this._items = filter(this.items, item => item.id !== id);
      }
    }
  }
  
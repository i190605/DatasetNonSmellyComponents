export default function ContextHelp({ icon, children, ...props }: ContextHelpProps) {
    return (
      <Popover {...props} content={children}>
        {icon || ContextHelp.defaultIcon}
      </Popover>
    );
  }
  
  ContextHelp.defaultProps = {
    icon: null,
    children: null,
  };
  
  ContextHelp.defaultIcon = <QuestionCircleFilledIcon className="context-help-default-icon" />;
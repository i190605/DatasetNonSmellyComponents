export default function Example() {
  const [searchValue, setSearchValue] = useState("");
  const [matches, setMatches] = useState(() => groupItems(defaultItems));

  const combobox = Ariakit.useComboboxStore({
    defaultItems,
    resetValueOnHide: true,
    value: searchValue,
    setValue: setSearchValue,
  });
  const select = Ariakit.useSelectStore({
    combobox,
    defaultItems,
    defaultValue: "",
  });

  const selectValue = select.useState("value");

  useEffect(() => {
    startTransition(() => {
      const items = matchSorter(countries, searchValue);
      setMatches(groupItems(items.map(getItem)));
    });
  }, [searchValue]);

  return (
    <>
      <div className="wrapper">
        <Ariakit.SelectLabel store={select}>Country</Ariakit.SelectLabel>
        <Ariakit.Select store={select} className="button">
          <span className="select-value">
            {selectValue || "Select a country"}
          </span>
          <Ariakit.SelectArrow />
        </Ariakit.Select>
        <Ariakit.SelectPopover
          store={select}
          gutter={4}
          sameWidth
          className="popover"
        >
          <div className="combobox-wrapper">
            <Ariakit.Combobox
              store={combobox}
              autoSelect
              placeholder="Search..."
              className="combobox"
            />
          </div>
          <Ariakit.ComboboxList store={combobox}>
            <SelectRenderer store={select} items={matches} gap={8} overscan={1}>
              {({ label, ...item }) => (
                <SelectRenderer
                  key={item.id}
                  className="group"
                  overscan={1}
                  {...item}
                  render={(props) => (
                    <Ariakit.SelectGroup {...props}>
                      <Ariakit.SelectGroupLabel className="group-label">
                        {label}
                      </Ariakit.SelectGroupLabel>
                      {props.children}
                    </Ariakit.SelectGroup>
                  )}
                >
                  {({ value, ...item }) => (
                    <Ariakit.ComboboxItem
                      key={item.id}
                      {...item}
                      className="select-item"
                      render={<Ariakit.SelectItem value={value} />}
                    >
                      <span className="select-item-value">{value}</span>
                    </Ariakit.ComboboxItem>
                  )}
                </SelectRenderer>
              )}
            </SelectRenderer>
          </Ariakit.ComboboxList>
        </Ariakit.SelectPopover>
      </div>
    </>
  );
}

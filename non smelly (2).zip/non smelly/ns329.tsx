function LinkWithIcon({ icon, alt, children, ...props }: LinkWithIconProps) {
    return (
      <Link.Component {...props}>
        {children} {icon} <span className="sr-only">{alt}</span>
      </Link.Component>
    );
  }
  
  Link.WithIcon = LinkWithIcon;
  function Dialog({ open, onClose, ...props }, ref) {
    const dialog = Ariakit.useDialogStore({
      open,
      setOpen: (open) => !open && onClose?.(),
    });
    return (
      <Ariakit.Dialog
        ref={ref}
        backdrop={<div className="backdrop" />}
        {...props}
        store={dialog}
      />
    );
  },
);

export { DialogHeading, DialogDismiss } from "@ariakit/react";

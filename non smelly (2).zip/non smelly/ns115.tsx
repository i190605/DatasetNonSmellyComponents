const ShortNumberCounter: React.FC<ShortNumberCounterProps> = ({ value }) => {
    const [rawNumber, unit, maxFractionDigits = 0] = value;
  
    const count = (
      <FormattedNumber
        value={rawNumber}
        maximumFractionDigits={maxFractionDigits}
      />
    );
  
    const values = { count, rawNumber };
  
    switch (unit) {
      case DECIMAL_UNITS.THOUSAND: {
        return (
          <FormattedMessage
            id='units.short.thousand'
            defaultMessage='{count}K'
            id='units.short.million'
            defaultMessage='{count}M'
            values={values}
          />
        );
      }
      case DECIMAL_UNITS.BILLION: {
        return (
          <FormattedMessage
            id='units.short.billion'
            defaultMessage='{count}B'
            values={values}
          />
        );
      }
      // Not sure if we should go farther - @Sasha-Sorokin
      default:
        return count;
    }
  };
  
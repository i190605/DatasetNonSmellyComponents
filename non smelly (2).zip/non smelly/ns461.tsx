function Editor({ column, onChange }: Props) {
    return (
      <React.Fragment>
        {/* @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message */}
        <Section>
          <Checkbox
            data-test="Table.ColumnEditor.Text.AllowHTML"
            checked={column.allowHTML}
            onChange={event => onChange({ allowHTML: event.target.checked })}>
            Allow HTML content
          </Checkbox>
        </Section>
  
        {column.allowHTML && (
          // @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message
          <Section>
            <Checkbox
              data-test="Table.ColumnEditor.Text.HighlightLinks"
              checked={column.highlightLinks}
              onChange={event => onChange({ highlightLinks: event.target.checked })}>
              Highlight links
            </Checkbox>
          </Section>
        )}
      </React.Fragment>
    );
  }
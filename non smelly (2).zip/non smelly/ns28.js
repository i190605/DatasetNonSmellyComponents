const Preset = React.memo(({ remove, apply, selected, preset }) => {
    const isSelected = preset.id === selected
  
    return (
      <div className="preset-container">
        <Button
          onClick={() => apply(preset)}
          disabled={isSelected}
          border={isSelected}
          selected={isSelected}
          hoverBackground={preset.backgroundColor}
          style={{
            height: '96px',
            borderRadius: '3px',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'center center',
            backgroundSize: 'contain',
            backgroundImage: `url('${preset.icon}')`,
            backgroundColor: preset.backgroundColor,
          }}
        />
        {preset.custom && (
          <Button
            center
            hoverBackground={COLORS.SECONDARY}
            background={COLORS.SECONDARY}
            onClick={() => remove(preset.id)}
            style={removeButtonStyles}
          >
            <Remove />
          </Button>
        )}
        <style jsx>
          {`
            .preset-container {
              display: flex;
              position: relative;
              flex: 0 0 96px;
              margin-right: 8px;
            }
  
            .preset-container :global(button:focus) {
              box-shadow: inset 0px 0px 0px 1px ${COLORS.SECONDARY};
            }
          `}
        </style>
      </div>
    )
  })
export function Tabs(props: Ariakit.TabProviderProps) {
  const { pathname } = useLocation();
  return (
    <Ariakit.TabProvider
      selectOnMove={false}
      selectedId={pathname}
      {...props}
    />
  );
}


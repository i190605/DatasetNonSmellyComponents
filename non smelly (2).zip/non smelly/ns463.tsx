function HelpTrigger({ title, href, className, children }: HelpTriggerProps) {
    return (
      <Tooltip
        title={
          <React.Fragment>
            {title}
            <i className="fa fa-external-link" style={{ marginLeft: 5 }} />
          </React.Fragment>
        }>
        <a className={className} href={href} target="_blank" rel="noopener noreferrer">
          {children}
        </a>
      </Tooltip>
    );
  }
  
  HelpTrigger.defaultValues = {
    title: null,
    className: null,
    children: null,
  };
  
  function Link(props: any) {
    return <a {...props} />;
  }
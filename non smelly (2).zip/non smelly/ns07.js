function CopyMenu({ isVisible, toggleVisibility, copyImage, carbonRef }) {
    const clipboardSupported = useClipboardSupport()
  
    const [showCopied, { loading: copied }] = useAsyncCallback(
      () => new Promise(res => setTimeout(res, 1000))
    )
  
    const [copy, { loading }] = useAsyncCallback(async (...args) => {
      if (clipboardSupported) {
        await copyImage(...args)
        showCopied()
      }
    })
  
    useKeyboardListener('⌘-⇧-c', e => {
      e.preventDefault()
      copy(e)
    })
  
    return (
      <div className="copy-menu-container">
        <div className="flex">
          <Button
            center
            border
            large
            padding="0 16px"
            margin="0 8px 0 0"
            onClick={toggleVisibility}
            color={COLORS.SECONDARY}
            title="Copy menu"
          >
            <CopySVG size={16} color={COLORS.SECONDARY} />
          </Button>
        </div>
        <Popout
          hidden={!isVisible}
          borderColor={COLORS.SECONDARY}
          pointerRight="24px"
          style={popoutStyle}
        >
          <div className="copy-row flex">
            <span>Copy to clipboard</span>
            {clipboardSupported && (
              <CopyButton id="export-clipboard" onClick={copy} disabled={loading}>
                {loading ? 'Copying…' : copied ? 'Copied!' : 'Image'}
              </CopyButton>
            )}
            <CopyEmbed title="Medium.com" mapper={toEncodedURL} />
            <CopyEmbed
              title="IFrame"
              mapper={url => toIFrame(url, carbonRef.clientWidth, carbonRef.clientHeight)}
            />
            <CopyEmbed title="Plain URL" mapper={toURL} />
          </div>
        </Popout>
        <style jsx>
          {`
            .copy-menu-container {
              position: relative;
              color: ${COLORS.SECONDARY};
              flex: 1;
              max-width: 40px;
            }
  
            .copy-row {
              flex-direction: column;
              justify-content: space-between;
              border-bottom: 1px solid ${COLORS.SECONDARY};
            }
  
            .copy-row :global(button) {
              border-top: 1px solid ${COLORS.SECONDARY};
            }
  
            .copy-row > span {
              padding: 8px;
              margin: 0 auto;
            }
          `}
        </style>
      </div>
    )
  }
function onProviderError(error: unknown) {
    // Silent the error, like upstream does
    if (process.env.NODE_ENV === 'production') return;
  
    // This browser does not advertise Intl support for this locale, we only print a warning
    // As-per the spec, the browser should select the best matching locale
    if (
      error &&
      typeof error === 'object' &&
      error instanceof Error &&
      error.message.match('MISSING_DATA')
    ) {
      console.warn(error.message);
    }
  
    console.error(error);
  }
  
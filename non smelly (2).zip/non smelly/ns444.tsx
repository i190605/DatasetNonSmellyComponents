export default function Section({ className, children, ...props }: SectionProps) {
    return (
      <div className={cx("visualization-editor-section", className)} {...props}>
        {children}
      </div>
    );
  }
  
  Section.defaultProps = {
    className: null,
    children: null,
  };
  
export default class ButtonTestCases extends React.Component {
    render() {
      return (
        <FixtureSet
          title="Custom Elements"
          description="Support for Custom Element DOM standards.">
          <TestCase title="Rendering into shadow root">
            <TestCase.ExpectedResult>
              You should see "Hello, World" printed below.{' '}
            </TestCase.ExpectedResult>
            {supportsCustomElements ? (
              <my-element />
            ) : (
              <div>This browser does not support custom elements.</div>
            )}
          </TestCase>
        </FixtureSet>
      );
    }
  }
  
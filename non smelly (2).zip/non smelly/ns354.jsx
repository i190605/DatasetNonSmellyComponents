export function General({ info }) {
    info = toPairs(info);
    return (
      <Card title="General" size="small">
        {info.length === 0 && <div className="text-muted text-center">No data</div>}
        {info.length > 0 && (
          <List
            size="small"
            itemLayout="vertical"
            dataSource={info}
            renderItem={([name, value]) => (
              <List.Item extra={<span className="badge">{value}</span>}>{toHuman(name)}</List.Item>
            )}
          />
        )}
      </Card>
    );
  }
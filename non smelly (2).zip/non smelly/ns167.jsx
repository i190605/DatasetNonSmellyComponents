const mapDispatchToProps = (dispatch, { intl }) => ({
    onLogout () {
      dispatch(openModal({
        modalType: 'CONFIRM',
        modalProps: {
          message: intl.formatMessage(messages.logoutMessage),
          confirm: intl.formatMessage(messages.logoutConfirm),
          closeWhenConfirm: false,
          onConfirm: () => logOut(),
        },
      }));
    },
  });
  
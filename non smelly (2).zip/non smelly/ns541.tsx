export const useComboboxCancel = createHook<ComboboxCancelOptions>(
    ({ store, ...props }) => {
      const context = useComboboxProviderContext();
      store = store || context;
  
      invariant(
        store,
        process.env.NODE_ENV !== "production" &&
          "ComboboxCancel must receive a `store` prop or be wrapped in a ComboboxProvider component.",
      );
  
      const onClickProp = props.onClick;
  
      const onClick = useEvent((event: MouseEvent<HTMLButtonElement>) => {
        onClickProp?.(event);
        if (event.defaultPrevented) return;
        store?.setValue("");
        // Move focus to the combobox input.
        store?.move(null);
      });
  
      const comboboxId = store.useState((state) => state.baseElement?.id);
  
      props = {
        children,
        "aria-label": "Clear input",
        // This aria-controls will ensure the combobox popup remains visible when
        // this element gets focused. This logic is done in the ComboboxPopover
        // component.
        "aria-controls": comboboxId,
        ...props,
        onClick,
      };
  
      props = useButton(props);
  
      return props;
    },
  );
  
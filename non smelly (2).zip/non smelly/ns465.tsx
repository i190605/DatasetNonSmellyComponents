export function updateVisualizationsSettings(options: any) {
    extend(visualizationsSettings, options);
  }
  
export default function Example() {
  return (
    <Ariakit.TooltipProvider type="label">
      <Ariakit.TooltipAnchor className="button" render={<Ariakit.Button />}>
        {icon}
      </Ariakit.TooltipAnchor>
      <Ariakit.Tooltip className="tooltip">Bold</Ariakit.Tooltip>
    </Ariakit.TooltipProvider>
  );
}

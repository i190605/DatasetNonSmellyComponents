export function FavoriteList({ title, resource, itemUrl, emptyState }) {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
  
    useEffect(() => {
      setLoading(true);
      resource
        .favorites()
        .then(({ results }) => setItems(results))
        .finally(() => setLoading(false));
    }, [resource]);
  
    return (
      <>
        <div className="d-flex align-items-center m-b-20">
          <p className="flex-fill f-500 c-black m-0">{title}</p>
          {loading && <LoadingOutlinedIcon />}
        </div>
        {!isEmpty(items) && (
          <div role="list" className="list-group">
            {items.map(item => (
              <Link key={itemUrl(item)} role="listitem" className="list-group-item" href={itemUrl(item)}>
                <span className="btn-favorite m-r-5">
                  <i className="fa fa-star" aria-hidden="true" />
                </span>
                {item.name}
                {item.is_draft && <span className="label label-default m-l-5">Unpublished</span>}
              </Link>
            ))}
          </div>
        )}
        {isEmpty(items) && !loading && emptyState}
      </>
    );
  }
export default function WorkplaceGroup(): React.Node {
    if (!isInternalFacebookBuild) {
      return null;
    }
  
    return (
      <div className={styles.WorkplaceGroupRow}>
        <Icon className={styles.ReportIcon} type="facebook" />
        <a
          className={styles.ReportLink}
          href={REACT_DEVTOOLS_WORKPLACE_URL}
          rel="noopener noreferrer"
          target="_blank"
          title="Report bug">
          Report this on Workplace
        </a>
        <div className={styles.FacebookOnly}>(Facebook employees only.)</div>
      </div>
    );
  }
  
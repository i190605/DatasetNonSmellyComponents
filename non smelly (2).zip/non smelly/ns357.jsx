export function Queues({ info }) {
    info = toPairs(info);
    return (
      <Card title="Queues" size="small">
        {info.length === 0 && <div className="text-muted text-center">No data</div>}
        {info.length > 0 && (
          <List
            size="small"
            itemLayout="vertical"
            dataSource={info}
            renderItem={([name, queue]) => (
              <List.Item extra={<span className="badge">{queue.size}</span>}>{name}</List.Item>
            )}
          />
        )}
      </Card>
    );
  }
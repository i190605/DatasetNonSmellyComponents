export default function Switch({ id, children, disabled, ...props }: Props) {
    const fallbackId = useMemo(
      () =>
        `visualization-editor-control-${Math.random()
          .toString(36)
          .substr(2, 10)}`,
      []
    );
    id = id || fallbackId;
  
    if (children) {
      return (
        <label htmlFor={id} className="switch-with-label">
          <AntSwitch id={id} disabled={disabled} {...props} />
          <Typography.Text className="switch-text" disabled={disabled}>
            {children}
          </Typography.Text>
        </label>
      );
    }
  
    return <AntSwitch {...props} />;
  }
  
  Switch.defaultProps = {
    id: null,
    disabled: false,
    children: null,
  };
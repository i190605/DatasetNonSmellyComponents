const mapDispatchToProps = dispatch => {
    return {
      onConfirm(account) {
        dispatch(blockAccount(account.get('id')));
      },
  
      onBlockAndReport(account) {
        dispatch(blockAccount(account.get('id')));
        dispatch(initReport(account));
      },
  
      onClose() {
        dispatch(closeModal({
          modalType: undefined,
          ignoreFocus: false,
        }));
      },
    };
  };
  
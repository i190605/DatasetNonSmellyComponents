function Drawer(props) {
    return (
      <Popout hidden={!props.isVisible} pointerRight="14px" style={{ width: '160px', right: 0 }}>
        <div className="flex column">
          <Link href="/snippets">
            <Button large center padding="0.5rem 0" style={{ borderBottom: '1px solid' }}>
              <img src="/static/svg/snippets.svg" alt="Snippets page" width="16px" /> Snippets{' '}
            </Button>
          </Link>
          <Link href="/account">
            <Button large center padding="0.5rem 0" style={{ borderBottom: '1px solid' }}>
              <img
                src="/static/svg/person.svg"
                alt="Account"
                width="16px"
                style={{ left: '-2px', marginRight: 'calc(1rem - 3px)' }}
              />{' '}
              Account
            </Button>
          </Link>
          <Button large center padding="0.5rem 0" onClick={logout}>
            Sign Out
          </Button>
        </div>
        <style jsx>
          {`
            .column {
              flex-direction: column;
            }
            img {
              position: relative;
              margin-right: 1rem;
            }
          `}
        </style>
      </Popout>
    )
  }
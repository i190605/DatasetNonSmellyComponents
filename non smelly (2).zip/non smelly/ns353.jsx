export function OtherJobsTable({ loading, items }) {
    return (
      <Table
        loading={loading}
        columns={otherJobsColumns}
        rowKey="id"
        dataSource={items}
        pagination={{
          defaultPageSize: 25,
          pageSizeOptions: ["10", "25", "50"],
          showSizeChanger: true,
        }}
      />
    );
  }
  
  OtherJobsTable.propTypes = TablePropTypes;
  
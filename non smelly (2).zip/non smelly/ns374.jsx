function deleteGroup(event, group, onGroupDeleted) {
    Modal.confirm({
      title: "Delete Group",
      content: "Are you sure you want to delete this group?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk: () => {
        Group.delete(group).then(() => {
          notification.success("Group deleted successfully.");
          onGroupDeleted();
        });
      },
    });
  }
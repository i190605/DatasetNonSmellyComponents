const ColumnSubheading = ({ text }) => {
    return (
      <div className='column-subheading'>
        {text}
      </div>
    );
  };
  
  ColumnSubheading.propTypes = {
    text: PropTypes.string.isRequired,
  };
  
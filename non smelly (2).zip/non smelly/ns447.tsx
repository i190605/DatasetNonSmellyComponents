export const UpdateOptionsStrategy = {
    replace: (existingOptions: any, newOptions: any) => merge({}, newOptions),
    shallowMerge: (existingOptions: any, newOptions: any) => extend({}, existingOptions, newOptions),
    deepMerge: (existingOptions: any, newOptions: any) => merge({}, existingOptions, newOptions),
  };
  
  /*
  (ts-migrate) TODO: Migrate the remaining prop types
  ...EditorPropTypes
  */
  type OwnProps = {
    tabs?: {
      key: string;
      title: string | ((...args: any[]) => any);
      isAvailable?: (...args: any[]) => any;
      component: (...args: any[]) => any;
    }[];
  };
  
  type Props = OwnProps & typeof TabbedEditor.defaultProps;
  
export const MetaTags = React.memo(() => (
    <Head>
      <meta charSet="utf-8" />
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description" content={description} />
      <meta name="application-name" content={title} />
      <meta name="twitter:card" content="summary" />
      <meta name="twitter:site" content="@carbon_app" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content="https://carbon.now.sh/static/brand/banner.png" />
      <meta name="og:title" content={title} />
      <meta name="og:description" content={description} />
      <meta name="og:image" content="/static/brand/banner.png" />
      <meta name="theme-color" content={COLORS.BLACK} />
      <meta name="apple-mobile-web-app-status-bar-style" content={COLORS.BLACK} />
      <title>{title} | Create and share beautiful images of your source code</title>
      <link rel="shortcut icon" href="/favicon.ico" />
      <link rel="manifest" href="/manifest.json" />
      <link rel="apple-touch-icon" href="/static/brand/apple-touch-icon.png" />
    </Head>
  ))
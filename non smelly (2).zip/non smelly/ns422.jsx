export default function PasswordLinkAlert(props) {
    const { user, passwordLink, ...restProps } = props;
  
    if (!isString(passwordLink)) {
      return null;
    }
  
    return (
      <DynamicComponent name="UserProfile.PasswordLinkAlert" {...props}>
        <Alert
          message="Email not sent!"
          description={
            <React.Fragment>
              <p>
                The mail server is not configured, please send the following link to <b>{user.name}</b>:
              </p>
              <InputWithCopy value={absoluteUrl(passwordLink)} aria-label="Password link" readOnly />
            </React.Fragment>
          }
          type="warning"
          className="m-t-20"
          closable
          {...restProps}
        />
      </DynamicComponent>
    );
  }
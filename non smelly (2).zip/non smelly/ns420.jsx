export default function GeneralSettings(props) {
    return (
      <DynamicComponent name="OrganizationSettings.GeneralSettings" {...props}>
        <h3 className="m-t-0">General</h3>
        <hr />
        <FormatSettings {...props} />
        <PlotlySettings {...props} />
        <FeatureFlagsSettings {...props} />
        <BeaconConsentSettings {...props} />
      </DynamicComponent>
    );
  }
  
class IframeSubtree extends React.Component {
    warned = false;
    render() {
      if (!this.warned) {
        console.error(
          `IFrame has not yet been implemented for React v${React.version}`
        );
        this.warned = true;
      }
      return <div>{this.props.children}</div>;
    }
  }
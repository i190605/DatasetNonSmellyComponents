class EventPooling extends React.Component {
    render() {
      return (
        <FixtureSet title="Event Pooling">
          <MouseMove />
          <Persistence />
        </FixtureSet>
      );
    }
  }
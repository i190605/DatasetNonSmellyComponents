export default function routeWithUserSession<P extends {} = {}>({
    render: originalRender,
    bodyClass,
    ...rest
  }: RouteWithUserSessionOptions<P>) {
    return {
      ...rest,
      render: (currentRoute: CurrentRoute<P>) => {
        const props = {
          render: originalRender,
          bodyClass,
          currentRoute,
        };
        return (
          <DynamicComponent
            {...props}
            name={UserSessionWrapperDynamicComponentName}
            fallback={<UserSessionWrapper {...props} />}
          />
        );
      },
    };
  }
  
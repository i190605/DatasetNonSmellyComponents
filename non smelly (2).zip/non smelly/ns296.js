export default function TimeoutView({
    callStack,
    children,
    componentStack,
    dismissError = null,
    errorMessage,
  }: Props): React.Node {
    return (
      <div className={styles.ErrorBoundary}>
        {children}
        <div className={styles.ErrorInfo}>
          <div className={styles.HeaderRow}>
            <div className={styles.TimeoutHeader}>
              {errorMessage || 'Timed out waiting'}
            </div>
            <Button className={styles.CloseButton} onClick={dismissError}>
              Retry
              <ButtonIcon className={styles.CloseButtonIcon} type="close" />
            </Button>
          </div>
          {!!componentStack && (
            <div className={styles.TimeoutStack}>
              The timeout occurred {componentStack.trim()}
            </div>
          )}
        </div>
      </div>
    );
  }
  
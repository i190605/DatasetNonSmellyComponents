export function OpenLinkButton({ onClick, size, color }: IconButtonProps) {
	return (
		<BaseButton onClick={onClick} icon={faSquareArrowUpRight} name='Open in another app' size={size} color={color} />
	);
}

export function CloseButton({ onClick, size, color }: IconButtonProps) {
	return (
		<BaseButton onClick={onClick} icon={faXmark} name='Close' size={size} color={color} hoverColor={'red'} />
	);
}

export function DownloadButton({ onClick, size, color }: IconButtonProps) {
	return (
		<BaseButton onClick={onClick} icon={faDownload} name='Download' size={size} color={color} />
	);
}

export function PrintButton({ onClick, size, color }: IconButtonProps) {
	return (
		<BaseButton onClick={onClick} icon={faPrint} name='Print' size={size} color={color} />
	);
}

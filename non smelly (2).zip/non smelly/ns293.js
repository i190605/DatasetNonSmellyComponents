export default function ReportNewIssue({
    callStack,
    componentStack,
    errorMessage,
  }: Props): React.Node {
    let bugURL = process.env.GITHUB_URL;
    if (!bugURL) {
      return null;
    }
  
    const gitHubAPISearch =
      errorMessage !== null ? searchGitHubIssuesURL(errorMessage) : '(none)';
  
    const title = `[DevTools Bug] ${errorMessage || ''}`;
  
    const parameters = [
      `template=${TEMPLATE}`,
      `labels=${encodeURIComponent(LABELS.join(','))}`,
      `title=${encodeURIComponent(title)}`,
      `automated_package=${process.env.DEVTOOLS_PACKAGE || ''}`,
      `automated_version=${process.env.DEVTOOLS_VERSION || ''}`,
      `automated_error_message=${encodeURIComponent(errorMessage || '')}`,
      `automated_call_stack=${encodeURIComponent(callStack || '')}`,
      `automated_component_stack=${encodeURIComponent(componentStack || '')}`,
      `automated_github_query_string=${gitHubAPISearch}`,
    ];
  
    bugURL += `/issues/new?${parameters.join('&')}`;
  
    return (
      <div className={styles.GitHubLinkRow}>
        <Icon className={styles.ReportIcon} type="bug" />
        <a
          className={styles.ReportLink}
          href={bugURL}
          rel="noopener noreferrer"
          target="_blank"
          title="Report bug">
          Report this issue
        </a>
        <div className={styles.ReproSteps}>
          (Please include steps on how to reproduce it and the components used.)
        </div>
      </div>
    );
  }
  
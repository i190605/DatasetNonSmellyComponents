export const managePopout = WrappedComponent => {
    class PopoutManager extends React.Component {
      state = {
        isVisible: false,
      }
  
      toggleVisibility = () => this.setState(toggle('isVisible'))
  
      handleClickOutside = () => this.setState({ isVisible: false })
  
      handleKeyDown = e => {
        if (e.key === 'Escape') {
          this.handleClickOutside()
        }
      }
  
      componentDidMount() {
        document.addEventListener('keydown', this.handleKeyDown)
      }
  
      componentWillUnmount() {
        document.removeEventListener('keydown', this.handleKeyDown)
      }
  
      render() {
        return (
          <WrappedComponent
            {...this.props}
            isVisible={this.state.isVisible}
            toggleVisibility={this.toggleVisibility}
          />
        )
      }
    }
  
    return enhanceWithClickOutside(PopoutManager)
  }
  
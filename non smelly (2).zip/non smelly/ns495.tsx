
export const ComboboxItem = forwardRef<HTMLDivElement, ComboboxItemProps>(
    function ComboboxItem(props, ref) {
      return (
        // Here we're combining both SelectItem and ComboboxItem into the same
        // element. SelectItem adds the multi-selectable attributes to the element
        // (for example, aria-selected).
        <Ariakit.SelectItem
          ref={ref}
          className="combobox-item"
          {...props}
          render={<Ariakit.ComboboxItem />}
        >
          <Ariakit.SelectItemCheck />
          {props.children || props.value}
        </Ariakit.SelectItem>
      );
    },
  );
  
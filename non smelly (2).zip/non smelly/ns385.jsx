export default function Layout({ children, className = undefined, ...props }) {
    return (
      <div className={classNames("layout-with-sidebar", className)} {...props}>
        {children}
      </div>
    );
  }
  
  Layout.propTypes = propTypes;
  Layout.defaultProps = defaultProps;
  
  Layout.Sidebar = Sidebar;
  Layout.Content = Content;
  
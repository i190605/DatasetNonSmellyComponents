export function QueryJobsTable({ loading, items }) {
    return (
      <Table
        loading={loading}
        columns={queryJobsColumns}
        rowKey="id"
        dataSource={items}
        pagination={{
          defaultPageSize: 25,
          pageSizeOptions: ["10", "25", "50"],
          showSizeChanger: true,
        }}
      />
    );
  }
  
  QueryJobsTable.propTypes = TablePropTypes;
  
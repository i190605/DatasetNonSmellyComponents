const propTypes = {
    className: PropTypes.string,
    children: PropTypes.node,
  };
  
  const defaultProps = {
    className: null,
    children: null,
  };
  
  // Sidebar
  
  function Sidebar({ className, children, ...props }) {
    return (
      <div className={classNames("layout-sidebar", className)} {...props}>
        <div>{children}</div>
      </div>
    );
  }
  
  Sidebar.propTypes = propTypes;
  Sidebar.defaultProps = defaultProps;
  
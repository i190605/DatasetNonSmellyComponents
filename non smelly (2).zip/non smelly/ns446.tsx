
function TextArea({ className, ...otherProps }: any) {
    return <AntInput.TextArea className={cx("visualization-editor-text-area", className)} {...otherProps} />;
  }
  
export default class ComposeContainer extends PureComponent {

    render () {
      return (
        <IntlProvider>
          <Provider store={store}>
            <Compose />
          </Provider>
        </IntlProvider>
      );
    }
  
  }
export function DataSourcePreviewCard({ dataSource, withLink, children, ...props }) {
    const imageUrl = `static/images/db-logos/${dataSource.type}.png`;
    const title = withLink ? <Link href={"data_sources/" + dataSource.id}>{dataSource.name}</Link> : dataSource.name;
    return (
      <PreviewCard {...props} imageUrl={imageUrl} title={title}>
        {children}
      </PreviewCard>
    );
  }
  
  DataSourcePreviewCard.propTypes = {
    dataSource: PropTypes.shape({
      name: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
    }).isRequired,
    withLink: PropTypes.bool,
    children: PropTypes.node,
  };
  
  DataSourcePreviewCard.defaultProps = {
    withLink: false,
    children: null,
  };
  
function useClipboardSupport() {
    const [isClipboardSupported, setClipboardSupport] = React.useState(false)
  
    React.useEffect(() => {
      setClipboardSupport(
        window.navigator && window.navigator.clipboard && typeof ClipboardItem === 'function'
      )
    }, [])
  
    return isClipboardSupported
  }
  
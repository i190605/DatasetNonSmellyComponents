ApiKeySessionWrapper.propTypes = {
    apiKey: PropTypes.string.isRequired,
    renderChildren: PropTypes.func,
  };
  
  ApiKeySessionWrapper.defaultProps = {
    renderChildren: () => null,
  };
  
  export default function routeWithApiKeySession({ render, getApiKey, ...rest }) {
    return {
      ...rest,
      render: currentRoute => (
        <ApiKeySessionWrapper apiKey={getApiKey(currentRoute)} currentRoute={currentRoute} renderChildren={render} />
      ),
    };
  }
  
function DateRangeParameter(props) {
    const options = includes(props.type, "datetime-range") ? DYNAMIC_DATETIME_OPTIONS : DYNAMIC_DATE_OPTIONS;
    return <DynamicDateRangePicker {...props} dynamicButtonOptions={{ options }} />;
  }
  
  DateRangeParameter.propTypes = {
    type: PropTypes.string,
    className: PropTypes.string,
    value: PropTypes.any, // eslint-disable-line react/forbid-prop-types
    parameter: PropTypes.any, // eslint-disable-line react/forbid-prop-types
    onSelect: PropTypes.func,
  };
  
  DateRangeParameter.defaultProps = {
    type: "",
    className: "",
    value: null,
    parameter: null,
    onSelect: () => {},
  };
  
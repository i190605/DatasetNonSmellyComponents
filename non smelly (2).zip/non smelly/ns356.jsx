export function DatabaseMetrics({ info }) {
    return (
      <Card title="Redash Database" size="small">
        {info.length === 0 && <div className="text-muted text-center">No data</div>}
        {info.length > 0 && (
          <List
            size="small"
            itemLayout="vertical"
            dataSource={info}
            renderItem={([name, size]) => (
              <List.Item extra={<span className="badge">{prettySize(size)}</span>}>{name}</List.Item>
            )}
          />
        )}
      </Card>
    );
  }
  
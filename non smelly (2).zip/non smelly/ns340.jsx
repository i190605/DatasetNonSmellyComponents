export function UserPreviewCard({ user, withLink, children, ...props }) {
    const title = withLink ? <Link href={"users/" + user.id}>{user.name}</Link> : user.name;
    return (
      <PreviewCard {...props} imageUrl={user.profile_image_url} title={title} body={user.email}>
        {children}
      </PreviewCard>
    );
  }
  
  UserPreviewCard.propTypes = {
    user: PropTypes.shape({
      profile_image_url: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      email: PropTypes.string.isRequired,
    }).isRequired,
    withLink: PropTypes.bool,
    children: PropTypes.node,
  };
  
  UserPreviewCard.defaultProps = {
    withLink: false,
    children: null,
  };
  
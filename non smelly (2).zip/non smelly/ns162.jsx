class ComposePanel extends PureComponent {

    static contextTypes = {
      identity: PropTypes.object.isRequired,
    };
  
    static propTypes = {
      dispatch: PropTypes.func.isRequired,
    };
  
    onFocus = () => {
      const { dispatch } = this.props;
      dispatch(changeComposing(true));
    };
  
    onBlur = () => {
      const { dispatch } = this.props;
      dispatch(changeComposing(false));
    };
  
    componentDidMount () {
      const { dispatch } = this.props;
      dispatch(mountCompose());
    }
  
    componentWillUnmount () {
      const { dispatch } = this.props;
      dispatch(unmountCompose());
    }
  
    render() {
      const { signedIn } = this.context.identity;
  
      return (
        <div className='compose-panel' onFocus={this.onFocus}>
          <SearchContainer openInRoute />
  
          {!signedIn && (
            <>
              <ServerBanner />
              <div className='flex-spacer' />
            </>
          )}
  
          {signedIn && (
            <>
              <NavigationContainer onClose={this.onBlur} />
              <ComposeFormContainer singleColumn />
            </>
          )}
  
          <LinkFooter />
        </div>
      );
    }
  
  }
  
export default function GroupName({ group, onChange, ...props }) {
    if (!group) {
      return null;
    }
  
    const canEdit = currentUser.isAdmin && group.type !== "builtin";
  
    return (
      <h3 {...props}>
        <EditInPlace
          className="edit-in-place"
          isEditable={canEdit}
          ignoreBlanks
          onDone={name => updateGroupName(group, name, onChange)}
          value={group.name}
        />
      </h3>
    );
  }
  
  GroupName.propTypes = {
    group: PropTypes.shape({
      name: PropTypes.string.isRequired,
    }),
    onChange: PropTypes.func,
  };
  
  GroupName.defaultProps = {
    group: null,
    onChange: () => {},
  };
  
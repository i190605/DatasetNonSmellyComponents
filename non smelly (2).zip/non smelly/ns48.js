export default function RecordingInProgress(): React.Node {
    return (
      <div className={styles.Column}>
        <div className={styles.Header}>Profiling is in progress...</div>
        <div className={styles.Row}>
          Click the record button <RecordToggle /> to stop recording.
        </div>
      </div>
    );
  }
  
export const MenuItem = React.forwardRef<HTMLDivElement, MenuItemProps>(
    function MenuItem(props, ref) {
      return (
        <MotionMenuItem
          ref={ref}
          {...props}
          className={clsx("menu-item", props.className)}
        />
      );
    },
  );
  
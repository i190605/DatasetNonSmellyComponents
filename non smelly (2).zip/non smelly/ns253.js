async function callServer(id, args) {
    const response = fetch('/', {
      method: 'POST',
      headers: {
        Accept: 'text/x-component',
        'rsc-action': id,
      },
      body: await encodeReply(args),
    });
    const {returnValue, root} = await createFromFetch(response, {callServer});
    // Refresh the tree with the new RSC payload.
    startTransition(() => {
      updateRoot(root);
    });
    return returnValue;
  }
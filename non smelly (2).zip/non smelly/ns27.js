class Popout extends React.PureComponent {
    static defaultProps = {
      borderColor: COLORS.SECONDARY,
      style: {},
    }
  
    render() {
      const { id, children, borderColor, style, hidden, pointerLeft, pointerRight } = this.props
  
      if (hidden) {
        return null
      }
  
      return (
        <div id={id} className="popout" style={style}>
          <WindowPointer fromLeft={pointerLeft} fromRight={pointerRight} color={borderColor} />
          {children}
          <style jsx>
            {`
              .popout {
                position: absolute;
                background-color: ${COLORS.BLACK};
                border: 2px solid ${borderColor};
                border-radius: 3px;
                margin-top: 10px;
                font-size: 12px;
                z-index: 1;
              }
            `}
          </style>
        </div>
      )
    }
  }
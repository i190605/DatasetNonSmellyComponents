export class WrappedSwitch extends PureComponent {
    static contextTypes = {
      router: PropTypes.object,
    };
  
    render () {
      const { multiColumn, children } = this.props;
      const { location } = this.context.router.route;
  
      const decklessLocation = multiColumn && location.pathname.startsWith('/deck')
        ? {...location, pathname: location.pathname.slice(5)}
        : location;
  
      return (
        <Switch location={decklessLocation}>
          {Children.map(children, child => child ? cloneElement(child, { multiColumn }) : null)}
        </Switch>
      );
    }
  
  }
  
  WrappedSwitch.propTypes = {
    multiColumn: PropTypes.bool,
    children: PropTypes.node,
  };
  
  
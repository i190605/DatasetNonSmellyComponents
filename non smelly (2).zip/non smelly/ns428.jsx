export function restoreSession() {
    if (!restoreSessionPromise) {
      restoreSessionPromise = new Promise(resolve => {
        showRestoreSessionPrompt(Auth.getLoginUrl(), () => {
          restoreSessionPromise = null;
          resolve();
        });
      });
    }
  
    return restoreSessionPromise;
  }
  
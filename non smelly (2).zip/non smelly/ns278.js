export default function Badge({
    className,
    hocDisplayNames,
    type,
    children,
  }: Props): React.Node {
    if (hocDisplayNames === null || hocDisplayNames.length === 0) {
      return null;
    }
  
    const totalBadgeCount = hocDisplayNames.length;
  
    return (
      <Fragment>
        <div className={`${styles.Badge} ${className || ''}`}>{children}</div>
        {totalBadgeCount > 1 && (
          <div className={styles.ExtraLabel}>+{totalBadgeCount - 1}</div>
        )}
      </Fragment>
    );
  }
  
class VectorWidget extends React.Component {
    /**
     * Initialize state members.
     */
    state = {degrees: 0, velocity: 0, drag: MOUSE_UP_DRAG};
  
    /**
     * When the component is mounted into the document - this is similar to a
     * constructor, but invoked when the instance is actually mounted into the
     * document. Here, we'll just set up an animation loop that invokes our
     * method. Binding of `this.onTick` is not needed because all React methods
     * are automatically bound before being mounted.
     */
    componentDidMount() {
      this._interval = window.setInterval(this.onTick, 20);
    }
  
    componentWillUnmount() {
      window.clearInterval(this._interval);
    }
  
    onTick = () => {
      var nextDegrees = this.state.degrees + BASE_VEL + this.state.velocity;
      var nextVelocity = this.state.velocity * this.state.drag;
      this.setState({degrees: nextDegrees, velocity: nextVelocity});
    };
  
    /**
     * When mousing down, we increase the friction down the velocity.
     */
    handleMouseDown = () => {
      this.setState({drag: MOUSE_DOWN_DRAG});
    };
  
    /**
     * Cause the rotation to "spring".
     */
    handleMouseUp = () => {
      var nextVelocity = Math.min(this.state.velocity + CLICK_ACCEL, MAX_VEL);
      this.setState({velocity: nextVelocity, drag: MOUSE_UP_DRAG});
    };
  
    /**
     * This is the "main" method for any component. The React API allows you to
     * describe the structure of your UI component at *any* point in time.
     */
    render() {
      return (
        <Surface width={700} height={700} style={{cursor: 'pointer'}}>
          {this.renderGraphic(this.state.degrees)}
        </Surface>
      );
    }
  
    /**
     * Better SVG support for React coming soon.
     */
    renderGraphic = rotation => {
      return (
        <Group onMouseDown={this.handleMouseDown} onMouseUp={this.handleMouseUp}>
          <Group x={210} y={135}>
            <Shape fill="rgba(0,0,0,0.1)" d={BORDER_PATH} />
            <Shape fill="#7BC7BA" d={BG_PATH} />
            <Shape fill="#DCDCDC" d={BAR_PATH} />
            <Shape fill="#D97B76" d={RED_DOT_PATH} />
            <Shape fill="#DBBB79" d={YELLOW_DOT_PATH} />
            <Shape fill="#A6BD8A" d={GREEN_DOT_PATH} />
            <Group x={55} y={29}>
              <Group rotation={rotation} originX={84} originY={89}>
                <Group x={84} y={89}>
                  <Circle fill="#FFFFFF" radius={16} />
                </Group>
                  />
                  <Shape
                    d={RING_THREE_PATH}
                    transform={RING_THREE_ROTATE}
                    stroke="#FFFFFF"
                    strokeWidth={8}
                  />
                </Group>
              </Group>
            </Group>
          </Group>
        </Group>
      );
    };
  } 
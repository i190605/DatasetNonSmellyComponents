const renderProfileItem = (event: any) => {
    const profile = event.item as Profile;
    const titleStyle = { fontWeight: profile.id === profileConfig.currentProfileId ? 'bold' : 'normal' };
    return (
        <List.Item
            title={profile.name}
            style={style.profileListItem}
            titleStyle={titleStyle}
            left={() => <List.Icon icon="file-account-outline" />}
            key={profile.id}
            profileId={profile.id}
            onPress={() => { void onProfileItemPress(profile); }}
            onLongPress={() => {
                Alert.alert(
                    _('Configuration'),
                    '',
                    [
                        {
                            text: _('Edit'),
                            onPress: () => onEditProfile(profile.id),
                            style: 'default',
                        },
                        {
                            text: _('Delete'),
                            onPress: () => onDeleteProfile(profile),
                            style: 'default',
                        },
                        {
                            text: _('Close'),
                            onPress: () => {},
                            style: 'cancel',
                        },
                    ],
                );
            }}
        />
    );
};

return (
    <View style={style.root}>
        <ScreenHeader title={_('Profiles')} showSaveButton={false} showSideMenuButton={false} showSearchButton={false} />
        <View>
            <FlatList
                data={profiles}
                renderItem={renderProfileItem}
                keyExtractor={(profile: Profile) => profile.id}
            />
        </View>
        <FAB
            icon="plus"
            style={style.fab}
            onPress={() => {
                props.dispatch({
                    type: 'NAV_GO',
                    routeName: 'ProfileEditor',
                });
            }}
        />

    </View>
);
};

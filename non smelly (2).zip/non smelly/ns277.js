export default function ContextMenuItem({
    children,
    onClick,
    title,
  }: Props): React.Node {
    const {hideMenu} = useContext<RegistryContextType>(RegistryContext);
  
    const handleClick = (event: any) => {
      onClick();
      hideMenu();
    };
  
    return (
      <div
        className={styles.ContextMenuItem}
        onClick={handleClick}
        onTouchEnd={handleClick}>
        {children}
      </div>
    );
  }
  
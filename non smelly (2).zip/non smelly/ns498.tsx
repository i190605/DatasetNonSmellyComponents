export default function Example() {
  const [open, setOpen] = useState(false);
  return (
    <Menu
      label="Options"
      open={open}
      setOpen={setOpen}
      animate={open ? "open" : "closed"}
      initial="closed"
      exit="closed"
      variants={menu}
    >
      <MenuItem {...item}>Edit</MenuItem>
      <MenuItem {...item}>Share</MenuItem>
      <MenuItem {...item}>Delete</MenuItem>
      <MenuItem {...item}>Report</MenuItem>
    </Menu>
  );
}

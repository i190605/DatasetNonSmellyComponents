function ListItem({ item, keySuffix }: ListItemProps) {
    const commonProps = {
      key: `card${keySuffix}`,
      className: "visual-card",
      onClick: item.onClick,
      children: (
        <>
          <img alt={item.title} src={item.imgSrc} />
          <h3>{item.title}</h3>
        </>
      ),
    };
  
    return item.href ? <Link href={item.href} {...commonProps} /> : <PlainButton type="link" {...commonProps} />;
  }
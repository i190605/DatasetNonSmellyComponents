
const Context = React.createContext(api)

export function useAPI() {
  return React.useContext(Context)
}

export default Context

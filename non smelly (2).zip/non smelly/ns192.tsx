export default function PdfViewer(props: Props) {

	const iframeRef = useRef<HTMLIFrameElement>(null);

	const onClose = useCallback(() => {
		props.dispatch({
			type: 'DIALOG_CLOSE',
			name: 'pdfViewer',
		});
	}, [props.dispatch]);

	const openExternalViewer = useCallback(async () => {
		await CommandService.instance().execute('openItem', `joplin://${props.resource.id}`);
	}, [props.resource.id]);

	const textSelected = useCallback(async (text: string) => {
		if (!text) return;
		const itemType = ContextMenuItemType.Text;
		const menu = await contextMenu({
			itemType,
			resourceId: null,
			filename: null,
			mime: 'text/plain',
			textToCopy: text,
			linkToCopy: null,
			htmlToCopy: '',
			insertContent: () => { console.warn('insertContent() not implemented'); },
			fireEditorEvent: () => { console.warn('fireEditorEvent() not implemented'); },
		} as ContextMenuOptions, props.dispatch);

		menu.popup({ window: bridge().window() });
	}, [props.dispatch]);

	const onMessage_ = useCallback(async (event: any) => {
		if (!event.data || !event.data.name) {
			return;
		}

		if (event.data.name === 'close') {
			onClose();
		} else if (event.data.name === 'externalViewer') {
			await openExternalViewer();
		} else if (event.data.name === 'textSelected') {
			await textSelected(event.data.text);
		} else {
			console.error('Unknown event received', event.data.name);
		}
	}, [openExternalViewer, textSelected, onClose]);

	useEffect(() => {
		const iframe = iframeRef.current;
		iframe.contentWindow.addEventListener('message', onMessage_);
		return () => {
			// iframe.contentWindow is not always defined
			// https://github.com/laurent22/joplin/issues/7528
			if (iframe.contentWindow) iframe.contentWindow.removeEventListener('message', onMessage_);
		};
	}, [onMessage_]);

	const theme = themeStyle(props.themeId);

	return (
		<Window theme={theme}>
			<IFrame src="./vendor/lib/@joplin/pdf-viewer/index.html" x-url={Resource.fullPath(props.resource)}
				x-appearance={theme.appearance} ref={iframeRef}
				x-title={props.resource.title}
				x-anchorpage={props.pageNo}
				x-type="full"></IFrame>
		</Window>
	);
}

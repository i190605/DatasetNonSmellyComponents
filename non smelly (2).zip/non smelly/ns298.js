export default function UpdateExistingIssue({
    gitHubIssue,
  }: {
    gitHubIssue: GitHubIssue,
  }): React.Node {
    const {title, url} = gitHubIssue;
    return (
      <div className={styles.GitHubLinkRow}>
        <Icon className={styles.ReportIcon} type="bug" />
        <div className={styles.UpdateExistingIssuePrompt}>
          Update existing issue:
        </div>
        <a
          className={styles.ReportLink}
          href={url}
          rel="noopener noreferrer"
          target="_blank"
          title="Report bug">
          {title}
        </a>
      </div>
    );
  }
  
export function Manager({ info }) {
    const items = info
      ? [
          <List.Item
            extra={
              <span className="badge">
                <TimeAgo date={info.lastRefreshAt} placeholder="n/a" />
              </span>
            }>
            Last Refresh
          </List.Item>,
          <List.Item
            extra={
              <span className="badge">
                <TimeAgo date={info.startedAt} placeholder="n/a" />
              </span>
            }>
            Started
          </List.Item>,
          <List.Item extra={<span className="badge">{info.outdatedQueriesCount}</span>}>
            Outdated Queries Count
          </List.Item>,
        ]
      : [];
  
    return (
      <Card title="Manager" size="small">
        {!info && <div className="text-muted text-center">No data</div>}
        {info && <List size="small" itemLayout="vertical" dataSource={items} renderItem={item => item} />}
      </Card>
    );
  }
  
function doArchiveQuery(query) {
    return Query.delete({ id: query.id })
      .then(() => {
        return extend(query.clone(), { is_archived: true, schedule: null });
      })
      .catch(error => {
        notification.error("Query could not be archived.");
        return Promise.reject(error);
      });
  }
  
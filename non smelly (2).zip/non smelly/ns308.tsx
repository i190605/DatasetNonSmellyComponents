export type UserSessionWrapperRenderChildrenProps<P> = {
    pageTitle?: string;
    onError: (error: Error) => void;
  } & P;
  
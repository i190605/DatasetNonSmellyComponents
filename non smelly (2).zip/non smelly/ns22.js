export default React.memo(function Meta() {
    return (
      <React.Fragment>
        <MetaTags />
        <Reset />
        <Font />
        <Typography />
      </React.Fragment>
    )
  })
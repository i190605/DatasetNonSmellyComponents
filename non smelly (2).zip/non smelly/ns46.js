export default function RecordToggle({disabled}: Props): React.Node {
    const {isProfiling, startProfiling, stopProfiling} =
      useContext(ProfilerContext);
  
    let className = styles.InactiveRecordToggle;
    if (disabled) {
      className = styles.DisabledRecordToggle;
    } else if (isProfiling) {
      className = styles.ActiveRecordToggle;
    }
  
    return (
      <Button
        className={className}
        disabled={disabled}
        onClick={isProfiling ? stopProfiling : startProfiling}
        testName="ProfilerToggleButton"
        title={isProfiling ? 'Stop profiling' : 'Start profiling'}>
        <ButtonIcon type="record" />
      </Button>
    );
  }
  
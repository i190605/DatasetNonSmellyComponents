class ActionBar extends PureComponent {

    static propTypes = {
      account: ImmutablePropTypes.map.isRequired,
      onLogout: PropTypes.func.isRequired,
      intl: PropTypes.object.isRequired,
    };
  
    handleLogout = () => {
      this.props.onLogout();
    };
  
    render () {
      const { intl } = this.props;
  
      let menu = [];
  
      menu.push({ text: intl.formatMessage(messages.edit_profile), href: '/settings/profile' });
      menu.push({ text: intl.formatMessage(messages.preferences), href: '/settings/preferences' });
      menu.push({ text: intl.formatMessage(messages.pins), to: '/pinned' });
      menu.push(null);
      menu.push({ text: intl.formatMessage(messages.follow_requests), to: '/follow_requests' });
      menu.push({ text: intl.formatMessage(messages.favourites), to: '/favourites' });
      menu.push({ text: intl.formatMessage(messages.bookmarks), to: '/bookmarks' });
      menu.push({ text: intl.formatMessage(messages.lists), to: '/lists' });
      menu.push({ text: intl.formatMessage(messages.followed_tags), to: '/followed_tags' });
      menu.push(null);
      menu.push({ text: intl.formatMessage(messages.mutes), to: '/mutes' });
      menu.push({ text: intl.formatMessage(messages.blocks), to: '/blocks' });
      menu.push({ text: intl.formatMessage(messages.domain_blocks), to: '/domain_blocks' });
      menu.push({ text: intl.formatMessage(messages.filters), href: '/filters' });
      menu.push(null);
      menu.push({ text: intl.formatMessage(messages.logout), action: this.handleLogout });
  
      return (
        <div className='compose__action-bar'>
          <div className='compose__action-bar-dropdown'>
            <DropdownMenuContainer items={menu} icon='bars' size={18} direction='right' />
          </div>
        </div>
      );
    }
  
  }
  
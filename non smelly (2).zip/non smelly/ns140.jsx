class ListForm extends PureComponent {

    static propTypes = {
      value: PropTypes.string.isRequired,
      disabled: PropTypes.bool,
      intl: PropTypes.object.isRequired,
      onChange: PropTypes.func.isRequired,
      onSubmit: PropTypes.func.isRequired,
    };
  
    handleChange = e => {
      this.props.onChange(e.target.value);
    };
  
    handleSubmit = e => {
      e.preventDefault();
      this.props.onSubmit();
    };
  
    handleClick = () => {
      this.props.onSubmit();
    };
  
    render () {
      const { value, disabled, intl } = this.props;
  
      const title = intl.formatMessage(messages.title);
  
      return (
        <form className='column-inline-form' onSubmit={this.handleSubmit}>
          <input
            className='setting-text'
            value={value}
            onChange={this.handleChange}
          />
  
          <IconButton
            disabled={disabled}
            icon='check'
            title={title}
            onClick={this.handleClick}
          />
        </form>
      );
    }
  
  }
  
function ApiKeySessionWrapper({ apiKey, currentRoute, renderChildren }) {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const { handleError } = useContext(ErrorBoundaryContext);
  
    useEffect(() => {
      let isCancelled = false;
      Auth.setApiKey(apiKey);
      Auth.loadConfig()
        .then(() => {
          if (!isCancelled) {
            setIsAuthenticated(true);
          }
        })
        .catch(() => {
          if (!isCancelled) {
            setIsAuthenticated(false);
          }
        });
      return () => {
        isCancelled = true;
      };
    }, [apiKey]);
  
    if (!isAuthenticated || clientConfig.disablePublicUrls) {
      return null;
    }
  
    return (
      <React.Fragment key={currentRoute.key}>
        {renderChildren({ ...currentRoute.routeParams, pageTitle: currentRoute.title, onError: handleError, apiKey })}
      </React.Fragment>
    );
  }
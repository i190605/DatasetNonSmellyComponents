function CopyButton(props) {
    return (
      <Button
        {...props}
        hoverColor={COLORS.SECONDARY}
        color="rgba(255, 255, 255, 0.7)"
        padding="8px"
      />
    )
  }
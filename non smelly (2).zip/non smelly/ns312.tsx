export type RouteWithUserSessionOptions<P> = {
    render: (props: UserSessionWrapperRenderChildrenProps<P>) => React.ReactNode;
    bodyClass?: string;
    title: string;
    path: string;
  };
  
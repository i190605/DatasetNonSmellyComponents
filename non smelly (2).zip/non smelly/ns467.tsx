export default function Renderer({ data, options, onOptionsChange }: any) {
    const [container, setContainer] = useState(null);
  
    const optionsWithoutBounds = useMemoWithDeepCompare(() => omit(options, ["bounds"]), [options]);
  
    const groups = useMemo(() => prepareData(data, optionsWithoutBounds), [data, optionsWithoutBounds]);
  
    const [map, setMap] = useState(null);
  
    useEffect(() => {
      if (container) {
        const _map = initMap(container);
        // @ts-expect-error ts-migrate(2345) FIXME: Argument of type '{ onBoundsChange: () => void; up... Remove this comment to see the full error message
        setMap(_map);
        return () => {
          _map.destroy();
        };
      }
    }, [container]);
  
    useEffect(() => {
      if (map) {
        // @ts-expect-error ts-migrate(2531) FIXME: Object is possibly 'null'.
        map.updateLayers(groups, optionsWithoutBounds);
      }
    }, [map, groups, optionsWithoutBounds]);
  
    useEffect(() => {
      if (map) {
        // @ts-expect-error ts-migrate(2531) FIXME: Object is possibly 'null'.
        map.updateBounds(options.bounds);
      }
    }, [map, options.bounds]);
  
    useEffect(() => {
      if (map && onOptionsChange) {
        // @ts-expect-error ts-migrate(2531) FIXME: Object is possibly 'null'.
        map.onBoundsChange = (bounds: any) => {
          onOptionsChange(merge({}, options, { bounds }));
        };
      }
    }, [map, options, onOptionsChange]);
  
    // @ts-expect-error ts-migrate(2322) FIXME: Type 'Dispatch<SetStateAction<null>>' is not assig... Remove this comment to see the full error message
    return <div className="map-visualization-container" ref={setContainer} />;
  }
  
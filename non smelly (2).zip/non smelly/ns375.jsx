export default function DeleteGroupButton({ group, title, onClick, children, ...props }) {
    if (!group) {
      return null;
    }
    const button = (
      <Button {...props} type="danger" onClick={event => deleteGroup(event, group, onClick)}>
        {children}
      </Button>
    );
  
    if (isString(title) && title !== "") {
      return (
        <Tooltip placement="top" title={title} mouseLeaveDelay={0}>
          {button}
        </Tooltip>
      );
    }
  
    return button;
  }
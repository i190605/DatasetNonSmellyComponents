export default function useArchiveQuery(query, onChange) {
    const handleChange = useImmutableCallback(onChange);
  
    return useCallback(() => {
      confirmArchive()
        .then(() => doArchiveQuery(query))
        .then(handleChange);
    }, [query, handleChange]);
  }
  
export interface UserSessionWrapperProps<P> {
    render: (props: UserSessionWrapperRenderChildrenProps<P>) => React.ReactNode;
    currentRoute: CurrentRoute<P>;
    bodyClass?: string;
  }
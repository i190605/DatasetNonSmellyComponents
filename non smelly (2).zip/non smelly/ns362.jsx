function ExpandedWidgetDialog({ dialog, widget, filters }) {
    return (
      <Modal
        {...dialog.props}
        title={
          <>
            <VisualizationName visualization={widget.visualization} /> <span>{widget.getQuery().name}</span>
          </>
        }
        width="95%"
        footer={<Button onClick={dialog.dismiss}>Close</Button>}>
        <VisualizationRenderer
          visualization={widget.visualization}
          queryResult={widget.getQueryResult()}
          filters={filters}
          context="widget"
        />
      </Modal>
    );
  }
  
  ExpandedWidgetDialog.propTypes = {
    dialog: DialogPropType.isRequired,
    widget: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
    filters: FiltersType,
  };
  
  ExpandedWidgetDialog.defaultProps = {
    filters: [],
  };
  
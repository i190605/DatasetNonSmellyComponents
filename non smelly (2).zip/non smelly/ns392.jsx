function areFiltersEqual(a, b) {
    if (a.length !== b.length) {
      return false;
    }
  
    a = fromPairs(map(a, item => [item.name, item]));
    b = fromPairs(map(b, item => [item.name, item]));
  
    return isEqual(a, b);
  }
interface ModalElementProps extends ModalProps {
	children: React.ReactNode;
	containerStyle?: ViewStyle;
	elevation?: number;
}

const ModalElement: React.FC<ModalElementProps> = ({
	children,
	containerStyle,
	...modalProps
}) => {
	return (
		<Modal {...modalProps}>
			<View style={[styleSheet.modalContainer, containerStyle ? containerStyle : null]}>
				{children}
			</View>
		</Modal>
	);
};

const styleSheet = StyleSheet.create({
	modalContainer: {
		marginTop: hasNotch() ? 65 : 15,
		marginBottom: hasNotch() ? 35 : 15,
	},
});


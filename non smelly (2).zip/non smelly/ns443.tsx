function SectionTitle({ className, children, ...props }: SectionTitleProps) {
    if (!children) {
      return null;
    }
  
    return (
      <h4 className={cx("visualization-editor-section-title", className)} {...props}>
        {children}
      </h4>
    );
  }
  
  SectionTitle.defaultProps = {
    className: null,
    children: null,
  };
  
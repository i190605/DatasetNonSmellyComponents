interface LinkWithIconProps extends LinkProps {
    children: string;
    icon: JSX.Element;
    alt: string;
    target?: "_self" | "_blank" | "_parent" | "_top";
  }
  
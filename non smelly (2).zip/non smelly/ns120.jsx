export default class AdminComponent extends PureComponent {

    static propTypes = {
      children: PropTypes.node.isRequired,
    };
  
    render () {
      const { children } = this.props;
  
      return (
        <IntlProvider>
          {children}
        </IntlProvider>
      );
    }
  
  }
  
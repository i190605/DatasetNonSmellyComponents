export default function initTextColumn(column: any) {
    const format = createTextFormatter(column.allowHTML && column.highlightLinks);
  
    function prepareData(row: any) {
      return {
        text: format(row[column.name]),
      };
    }
  
    function TextColumn({ row }: any) {
      // eslint-disable-line react/prop-types
      const { text } = prepareData(row);
      return column.allowHTML ? <HtmlContent>{text}</HtmlContent> : text;
    }
  
    TextColumn.prepareData = prepareData;
  
    return TextColumn;
  }
export default class SettingToggle extends PureComponent {

    static propTypes = {
      prefix: PropTypes.string,
      settings: ImmutablePropTypes.map.isRequired,
      settingPath: PropTypes.array.isRequired,
      label: PropTypes.node.isRequired,
      onChange: PropTypes.func.isRequired,
      defaultValue: PropTypes.bool,
      disabled: PropTypes.bool,
    };
  
    onChange = ({ target }) => {
      this.props.onChange(this.props.settingPath, target.checked);
    };
  
    render () {
      const { prefix, settings, settingPath, label, defaultValue, disabled } = this.props;
      const id = ['setting-toggle', prefix, ...settingPath].filter(Boolean).join('-');
  
      return (
        <div className='setting-toggle'>
          <Toggle disabled={disabled} id={id} checked={settings.getIn(settingPath, defaultValue)} onChange={this.onChange} onKeyDown={this.onKeyDown} />
          <label htmlFor={id} className='setting-toggle__label'>{label}</label>
        </div>
      );
    }
  
  }
  
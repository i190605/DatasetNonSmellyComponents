function DisabledInput({ children, minWidth }) {
    return (
      <div className="criteria-disabled-input" style={{ minWidth }}>
        {children}
      </div>
    );
  }
  
  DisabledInput.propTypes = {
    children: PropTypes.node.isRequired,
    minWidth: PropTypes.number.isRequired,
  };
  
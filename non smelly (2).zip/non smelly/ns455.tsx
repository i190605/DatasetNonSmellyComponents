function render(container: any, data: any, { xAxisLabel, yAxisLabel }: any) {
    container = d3.select(container);
  
    const containerBounds = container.node().getBoundingClientRect();
    const containerWidth = Math.floor(containerBounds.width);
    const containerHeight = Math.floor(containerBounds.height);
  
    const margin = {
      top: 10,
      right: 50,
      bottom: 40,
      left: 50,
      inner: 25,
    };
    const width = containerWidth - margin.right - margin.left;
    const height = containerHeight - margin.top - margin.bottom;
  
    let min = Infinity;
    let max = -Infinity;
    const mydata: any = [];
    let value = 0;
    let d = [];
  
    const columns = map(data.columns, col => col.name);
    // @ts-expect-error ts-migrate(2339) FIXME: Property 'scale' does not exist on type 'typeof im... Remove this comment to see the full error message
    const xscale = d3.scale
      .ordinal()
      .domain(columns)
      .rangeBands([0, containerWidth - margin.left - margin.right]);
  
    let boxWidth;
    if (columns.length > 1) {
      boxWidth = Math.min(xscale(columns[1]), 120.0);
    } else {
      boxWidth = 120.0;
    }
    margin.inner = boxWidth / 3.0;
  
    each(columns, (column, i) => {
      d = mydata[i] = [];
      each(data.rows, row => {
        value = row[column];
        d.push(value);
        if (value > max) max = Math.ceil(value);
        if (value < min) min = Math.floor(value);
      });
    });
  
    // @ts-expect-error ts-migrate(2339) FIXME: Property 'scale' does not exist on type 'typeof im... Remove this comment to see the full error message
    const yscale = d3.scale
      .linear()
      .domain([min * 0.99, max * 1.01])
      .range([height, 0]);
  
    const chart = box()
      .whiskers(calcIqr(1.5))
      // @ts-expect-error ts-migrate(2339) FIXME: Property 'width' does not exist on type '{ (g: any... Remove this comment to see the full error message
      .width(boxWidth - 2 * margin.inner)
      .height(height)
      .domain([min * 0.99, max * 1.01]);
    const xAxis = d3.svg
      // @ts-expect-error ts-migrate(2339) FIXME: Property 'axis' does not exist on type '(url: stri... Remove this comment to see the full error message
      .axis()
      .scale(xscale)
      .orient("bottom");
  
    const yAxis = d3.svg
      // @ts-expect-error ts-migrate(2339) FIXME: Property 'axis' does not exist on type '(url: stri... Remove this comment to see the full error message
      .axis()
      .scale(yscale)
      .orient("left");
  
    const xLines = d3.svg
      // @ts-expect-error ts-migrate(2339) FIXME: Property 'axis' does not exist on type '(url: stri... Remove this comment to see the full error message
      .axis()
      .scale(xscale)
      .tickSize(height)
      .orient("bottom");
  
    const yLines = d3.svg
      // @ts-expect-error ts-migrate(2339) FIXME: Property 'axis' does not exist on type '(url: stri... Remove this comment to see the full error message
      .axis()
      .scale(yscale)
      .tickSize(width)
      .orient("right");
export default class Compose extends PureComponent {

    render () {
      return (
        <div>
          <ComposeFormContainer autoFocus />
          <NotificationsContainer />
          <ModalContainer />
          <LoadingBarContainer className='loading-bar' />
        </div>
      );
    }
  
  }
  
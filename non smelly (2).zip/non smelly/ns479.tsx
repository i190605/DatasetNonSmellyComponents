export function ConfirmDialog({
  title = "Confirm",
  description = "Are you sure?",
  confirmLabel = "OK",
  cancelLabel = "Cancel",
  danger,
  open,
  onClose,
  onConfirm,
  onCancel,
}: Props) {
  const dialog = Ariakit.useDialogStore({
    open,
    setOpen(open) {
      if (!open) {
        onClose?.();
      }
    },
  });
  return (
    <Ariakit.Dialog
      store={dialog}
      backdrop={<div className="backdrop" />}
      className="dialog"
    >
      {title && (
        <Ariakit.DialogHeading className="heading">
          {title}
        </Ariakit.DialogHeading>
      )}
      {description && (
        <Ariakit.DialogDescription className="description">
          {description}
        </Ariakit.DialogDescription>
      )}
      <div className="buttons">
        {confirmLabel && (
          <Ariakit.DialogDismiss
            className={`button${danger ? " danger" : ""}`}
            onClick={onConfirm}
          >
            {confirmLabel}
          </Ariakit.DialogDismiss>
        )}
        {cancelLabel && (
          <Ariakit.DialogDismiss
            className="button secondary"
            onClick={onCancel}
            autoFocus
          >
            {cancelLabel}
          </Ariakit.DialogDismiss>
        )}
      </div>
    </Ariakit.Dialog>
  );
}

function SelectWithVirtualScroll({ options, ...props }: VirtualScrollSelectProps): JSX.Element {
    const dropdownMatchSelectWidth = useMemo<number | boolean>(() => {
      if (options && options.length > MIN_LEN_FOR_VIRTUAL_SCROLL) {
        const largestOpt = maxBy(options, "label.length");
  
        if (largestOpt) {
          const offset = 40;
          const optionText = largestOpt.label;
          const width = calculateTextWidth(optionText);
          if (width) {
            return width + offset;
          }
        }
  
        return true;
      }
  
      return false;
    }, [options]);
  
    return (
      <AntdSelect<string>
        dropdownMatchSelectWidth={dropdownMatchSelectWidth}
        options={options}
        allowClear={true}
        optionFilterProp="label" // as this component expects "options" prop
        {...props}
      />
    );
  }
  
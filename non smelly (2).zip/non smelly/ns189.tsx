class NoteStatusBarComponent extends React.Component<Props> {
	public style() {
		const theme = themeStyle(this.props.themeId);

		const style = {
			root: { ...theme.textStyle, backgroundColor: theme.backgroundColor,
				color: theme.colorFaded },
		};

		return style;
	}

	public render() {
		const note = this.props.note;
		return <div style={this.style().root}>{time.formatMsToLocal(note.user_updated_time)}</div>;
	}
}

export function QueuesTable({ loading, items }) {
    return (
      <Table
        loading={loading}
        columns={queuesColumns}
        rowKey="name"
        dataSource={items}
        pagination={{
          defaultPageSize: 25,
          pageSizeOptions: ["10", "25", "50"],
          showSizeChanger: true,
        }}
      />
    );
  }
  
  QueuesTable.propTypes = TablePropTypes;
  
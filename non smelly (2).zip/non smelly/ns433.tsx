export default function Label({ className, color, presetColors, ...props }: Props) {
    const name = useMemo(() => getColorName(validateColor(color), presetColors), [color, presetColors]);
  
    return (
      <span className={cx("color-label", className)} {...props}>
        {name}
      </span>
    );
  }
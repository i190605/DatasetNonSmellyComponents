export default function ZoomControls(props: ZoomControlsProps) {

	const zoomIn = () => {
		props.onChange(Math.min(props.zoom + 0.25, 2));
	};

	const zoomOut = () => {
		props.onChange(Math.max(props.zoom - 0.25, 0.5));
	};

	return (<ZoomGroup size={props.size || 0.8}>
		<FontAwesomeIcon icon={faMinus} title="Zoom Out" style={{ paddingRight: '0.2rem', cursor: 'pointer' }} onClick={zoomOut} />
		<span style={{ color: 'grey' }} >{props.zoom * 100}%</span>
		<FontAwesomeIcon icon={faPlus} title="Zoom In" style={{ paddingLeft: '0.2rem', cursor: 'pointer' }} onClick={zoomIn} />
	</ZoomGroup>);
}

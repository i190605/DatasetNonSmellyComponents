function combineFilters(localFilters, globalFilters) {
    // tiny optimization - to avoid unnecessary updates
    if (localFilters.length === 0 || globalFilters.length === 0) {
      return localFilters;
    }
  
    return map(localFilters, localFilter => {
      const globalFilter = find(globalFilters, f => f.name === localFilter.name);
      if (globalFilter) {
        return {
          ...localFilter,
          current: globalFilter.current,
        };
      }
      return localFilter;
    });
  }
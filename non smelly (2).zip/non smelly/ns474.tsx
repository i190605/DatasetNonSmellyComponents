export default function Example() {
  return (
    <Command
      role="button"
      className="button"
      onClick={() => alert("Accessible button clicked")}
      render={<div />}
    >
      Button
    </Command>
  );
}

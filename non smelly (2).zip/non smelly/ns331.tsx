function ExternalLink({
    icon = <i className="fa fa-external-link" aria-hidden="true" />,
    alt = "(opens in a new tab)",
    ...props
  }: Omit<LinkWithIconProps, "target">) {
    return <Link.WithIcon target="_blank" rel="noopener noreferrer" icon={icon} alt={alt} {...props} />;
  }
  
  Link.External = ExternalLink;
  
function Link({ children, ...props }: LinkProps) {
    return <Link.Component {...props}>{children}</Link.Component>;
  }
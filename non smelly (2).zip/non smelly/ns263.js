export default function App({assets}) {
    return (
      <Chrome title="Hello World" assets={assets}>
        <Content />
      </Chrome>
    );
  }
  
function Content({ className, children, ...props }) {
    return (
      <div className={classNames("layout-content", className)} {...props}>
        <div>{children}</div>
      </div>
    );
  }
  
  Content.propTypes = propTypes;
  Content.defaultProps = defaultProps;
  
  // Layout
  const selectValue = select.useState("value");
  return (
    <div className="filter">
      <Ariakit.Select
        ref={ref}
        className="button select"
        {...props}
        store={select}
        aria-labelledby={labelId}
      >
        <div>
          <span id={labelId} aria-hidden>
            {label}:{" "}
          </span>
          {selectValue || "Choose one"}
        </div>
      </Ariakit.Select>
      <Ariakit.SelectPopover
        store={select}
        aria-labelledby={labelId}
        gutter={4}
        className="popover"
      >
        {children}
      </Ariakit.SelectPopover>
      {onRemove && (
        <Ariakit.Button
          className="button select"
          aria-label={`Remove ${label} filter`}
          onClick={() => onRemove()}
        >
          &times;
        </Ariakit.Button>
      )}
    </div>
  );
});

interface FilterSelectItemProps extends Ariakit.SelectItemProps {
  children?: React.ReactNode;
}

export const FilterSelectItem = React.forwardRef<
  HTMLDivElement,
  FilterSelectItemProps
>(function FilterSelectItem(props, ref) {
  return (
    <Ariakit.SelectItem ref={ref} className="select-item" {...props}>
      <Ariakit.SelectItemCheck />
      {props.children ?? props.value}
    </Ariakit.SelectItem>
  );
});

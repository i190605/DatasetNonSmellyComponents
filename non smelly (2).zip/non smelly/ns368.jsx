export default function FileField({ form, field, ...otherProps }) {
    const { name, initialValue } = field;
    const { getFieldValue } = form;
    const disabled = getFieldValue(name) !== undefined && getFieldValue(name) !== initialValue;
  
    return (
      <Upload {...otherProps} beforeUpload={() => false}>
        <Button disabled={disabled}>
          <UploadOutlinedIcon /> Click to upload
        </Button>
      </Upload>
    );
  }
  
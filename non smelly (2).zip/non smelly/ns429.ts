export interface RedashRoute<P = {}, C extends Context = Context, R = any> extends UniversalRouterRoute<C, R> {
    path: string; // we don't use other UniversalRouterRoute options, path should be available and should be a string
    key?: string; // generated in Router.jsx
    title: string;
    render?: (currentRoute: CurrentRoute<P>) => React.ReactNode;
    getApiKey?: () => string;
  }
  
  interface RouteItem extends RedashRoute<any> {
    id: string | null;
  }
  
  function getRouteParamsCount(path: string) {
    const tokens = pathToRegexp.parse(path);
    return filter(tokens, isObject).length;
  }
export default function UserWebviewDialogButtonBar(props: Props) {
	function renderButtons() {
		const output = [];
		for (let i = 0; i < props.buttons.length; i++) {
			const b = props.buttons[i];
			const marginRight = i !== props.buttons.length - 1 ? '6px' : '0px';
			output.push(<StyledButton key={b.id} onClick={b.onClick} title={buttonTitle(b)} mr={marginRight}/>);
		}
		return output;
	}

	return (
		<StyledRoot>
			{renderButtons()}
		</StyledRoot>
	);
}

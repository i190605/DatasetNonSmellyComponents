function preparePresets(presetColors: any, presetColumns: any) {
    presetColors = isArray(presetColors) ? map(presetColors, v => [null, v]) : toPairs(presetColors);
    presetColors = map(presetColors, ([title, value]) => {
      if (isNil(value)) {
        return [title, null];
      }
      value = tinycolor(value);
      if (value.isValid()) {
        return [title, "#" + value.toHex().toUpperCase()];
      }
      return null;
    });
    return chunk(filter(presetColors), presetColumns);
  }
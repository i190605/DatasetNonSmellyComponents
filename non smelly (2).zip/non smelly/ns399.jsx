export default function MenuButton({ doDelete, canEdit, mute, unmute, muted }) {
    const [loading, setLoading] = useState(false);
  
    const execute = useCallback(action => {
      setLoading(true);
      action().finally(() => {
        setLoading(false);
      });
    }, []);
  
    const confirmDelete = useCallback(() => {
      Modal.confirm({
        title: "Delete Alert",
        content: "Are you sure you want to delete this alert?",
        okText: "Delete",
        okType: "danger",
        onOk: () => {
          setLoading(true);
          doDelete().catch(() => {
            setLoading(false);
          });
        },
        maskClosable: true,
        autoFocusButton: null,
      });
    }, [doDelete]);
  
    return (
      <Dropdown
        className={cx("m-l-5", { disabled: !canEdit })}
        trigger={[canEdit ? "click" : undefined]}
        placement="bottomRight"
        overlay={
          <Menu>
            <Menu.Item>
              {muted ? (
                <PlainButton onClick={() => execute(unmute)}>Unmute Notifications</PlainButton>
              ) : (
                <PlainButton onClick={() => execute(mute)}>Mute Notifications</PlainButton>
              )}
            </Menu.Item>
            <Menu.Item>
              <PlainButton onClick={confirmDelete}>Delete</PlainButton>
            </Menu.Item>
          </Menu>
        }>
        <Button aria-label="More actions">
          {loading ? <LoadingOutlinedIcon /> : <EllipsisOutlinedIcon rotate={90} aria-hidden="true" />}
        </Button>
      </Dropdown>
    );
  }
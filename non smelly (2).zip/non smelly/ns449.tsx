export default function createTabbedEditor(tabs: any) {
    return function TabbedEditorWrapper(props: any) {
      return <TabbedEditor {...props} tabs={tabs} />;
    };
  }
  
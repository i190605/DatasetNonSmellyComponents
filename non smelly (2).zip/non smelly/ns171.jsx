export class WrappedRoute extends Component {

    static propTypes = {
      component: PropTypes.func.isRequired,
      content: PropTypes.node,
      multiColumn: PropTypes.bool,
      componentParams: PropTypes.object,
    };
  
    static defaultProps = {
      componentParams: {},
    };
  
    static getDerivedStateFromError () {
      return {
        hasError: true,
      };
    }
  
    state = {
      hasError: false,
      stacktrace: '',
    };
  
    componentDidCatch (error) {
      StackTrace.fromError(error).then(stackframes => {
        this.setState({ stacktrace: error.toString() + '\n' + stackframes.map(frame => frame.toString()).join('\n') });
      }).catch(err => {
        console.error(err);
      });
    }
  
    renderComponent = ({ match }) => {
      const { component, content, multiColumn, componentParams } = this.props;
      const { hasError, stacktrace } = this.state;
  
      if (hasError) {
        return (
          <BundleColumnError
            stacktrace={stacktrace}
            multiColumn={multiColumn}
            errorType='error'
          />
        );
      }
  
      return (
        <BundleContainer fetchComponent={component} loading={this.renderLoading} error={this.renderError}>
          {Component => <Component params={match.params} multiColumn={multiColumn} {...componentParams}>{content}</Component>}
        </BundleContainer>
      );
    };
  
    renderLoading = () => {
      const { multiColumn } = this.props;
  
      return <ColumnLoading multiColumn={multiColumn} />;
    };
  
    renderError = (props) => {
      return <BundleColumnError {...props} errorType='network' />;
    };
  
    render () {
      const { component: Component, content, ...rest } = this.props;
  
      return <Route {...rest} render={this.renderComponent} />;
    }
  
  }
  
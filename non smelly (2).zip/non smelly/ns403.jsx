export function DashboardAndQueryFavoritesList() {
    return (
      <div className="tile">
        <div className="t-body tb-padding">
          <div className="row home-favorites-list">
            <div className="col-sm-6 m-t-20">
              <FavoriteList
                title="Favorite Dashboards"
                resource={Dashboard}
                itemUrl={dashboard => dashboard.url}
                emptyState={
                  <p>
                    <span className="btn-favorite m-r-5">
                      <i className="fa fa-star" aria-hidden="true" />
                    </span>
                    Favorite <Link href="dashboards">Dashboards</Link> will appear here
                  </p>
                }
              />
            </div>
            <div className="col-sm-6 m-t-20">
              <FavoriteList
                title="Favorite Queries"
                resource={Query}
                itemUrl={query => `queries/${query.id}`}
                emptyState={
                  <p>
                    <span className="btn-favorite m-r-5">
                      <i className="fa fa-star" aria-hidden="true" />
                    </span>
                    Favorite <Link href="queries">Queries</Link> will appear here
                  </p>
                }
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
class Statuses extends PureComponent {

    static propTypes = {
      onNextStep: PropTypes.func.isRequired,
      accountId: PropTypes.string.isRequired,
      availableStatusIds: ImmutablePropTypes.set.isRequired,
      selectedStatusIds: ImmutablePropTypes.set.isRequired,
      isLoading: PropTypes.bool,
      onToggle: PropTypes.func.isRequired,
    };
  
    handleNextClick = () => {
      const { onNextStep } = this.props;
      onNextStep('comment');
    };
  
    render () {
      const { availableStatusIds, selectedStatusIds, onToggle, isLoading } = this.props;
  
      return (
        <>
          <h3 className='report-dialog-modal__title'><FormattedMessage id='report.statuses.title' defaultMessage='Are there any posts that back up this report?' /></h3>
          <p className='report-dialog-modal__lead'><FormattedMessage id='report.statuses.subtitle' defaultMessage='Select all that apply' /></p>
  
          <div className='report-dialog-modal__statuses'>
            {isLoading ? <LoadingIndicator /> : availableStatusIds.union(selectedStatusIds).map(statusId => (
              <StatusCheckBox
                id={statusId}
                key={statusId}
                checked={selectedStatusIds.includes(statusId)}
                onToggle={onToggle}
              />
            ))}
          </div>
  
          <div className='flex-spacer' />
  
          <div className='report-dialog-modal__actions'>
            <Button onClick={this.handleNextClick}><FormattedMessage id='report.next' defaultMessage='Next' /></Button>
          </div>
        </>
      );
    }
  
  }
  
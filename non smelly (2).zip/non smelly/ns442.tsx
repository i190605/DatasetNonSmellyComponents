function TickFormatSpecs() {
    const { HelpTriggerComponent } = visualizationsSettings;
    return (
      <HelpTriggerComponent
        title="Tick Formatting"
        href="https://redash.io/help/user-guide/visualizations/formatting-axis"
        className="visualization-editor-context-help">
        {ContextHelp.defaultIcon}
      </HelpTriggerComponent>
    );
  }
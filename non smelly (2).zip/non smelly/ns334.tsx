function ButtonLink(props: ButtonProps) {
    return <ButtonLink.Component {...props} />;
  }
  Link.Button = ButtonLink;

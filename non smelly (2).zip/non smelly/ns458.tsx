export default function ColumnsSettings({ options, data, onOptionsChange }: any) {
    return (
      <React.Fragment>
        {/* @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message */}
        <Section>
          <Select
            layout="horizontal"
            label="Date (Bucket)"
            data-test="Cohort.DateColumn"
            value={options.dateColumn}
            onChange={(dateColumn: any) => onOptionsChange({ dateColumn })}>
            {map(data.columns, ({ name }) => (
              // @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message
              <Select.Option key={name} data-test={"Cohort.DateColumn." + name}>
                {name}
                {/* @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message */}
              </Select.Option>
            ))}
          </Select>
        </Section>
  
        {/* @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message */}
        <Section>
          <Select
            layout="horizontal"
            label="Stage"
            data-test="Cohort.StageColumn"
            value={options.stageColumn}
            onChange={(stageColumn: any) => onOptionsChange({ stageColumn })}>
            {map(data.columns, ({ name }) => (
              // @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message
              <Select.Option key={name} data-test={"Cohort.StageColumn." + name}>
                {name}
                {/* @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message */}
              </Select.Option>
            ))}
          </Select>
        </Section>
  
        {/* @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message */}
        <Section>
          <Select
            layout="horizontal"
            label="Bucket Population Size"
            data-test="Cohort.TotalColumn"
            value={options.totalColumn}
            onChange={(totalColumn: any) => onOptionsChange({ totalColumn })}>
            {map(data.columns, ({ name }) => (
              // @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message
              <Select.Option key={name} data-test={"Cohort.TotalColumn." + name}>
                {name}
                {/* @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message */}
              </Select.Option>
            ))}
          </Select>
        </Section>
  
        {/* @ts-expect-error ts-migrate(2745) FIXME: This JSX tag's 'children' prop expects type 'never... Remove this comment to see the full error message */}
        <Section>
          <Select
            layout="horizontal"
            label="Stage Value"
            data-test="Cohort.ValueColumn"
            value={options.valueColumn}
            onChange={(valueColumn: any) => onOptionsChange({ valueColumn })}>
            {map(data.columns, ({ name }) => (
              // @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message
              <Select.Option key={name} data-test={"Cohort.ValueColumn." + name}>
                {name}
                {/* @ts-expect-error ts-migrate(2339) FIXME: Property 'Option' does not exist on type '({ class... Remove this comment to see the full error message */}
              </Select.Option>
            ))}
          </Select>
        </Section>
      </React.Fragment>
    );
  }
  
  ColumnsSettings.propTypes = EditorPropTypes;
  